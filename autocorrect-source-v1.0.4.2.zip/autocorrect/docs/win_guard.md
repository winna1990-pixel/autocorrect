# win_guard.py — стабильность замены на Windows (кодер 3)

Файлы: `win_guard.py`, `test_win_guard.py` (57 проверок, `python test_win_guard.py`, без Windows и GUI).
Зависимостей нет (только ctypes). `comtypes` — по желанию: с ним ловим поля паролей в браузерах/WPF через UI Automation, без него только классические Win32 Edit.

## Что чинит в v1.0.2
1. **Быстрая печать.** Сейчас `_apply` спит 10 мс и шлёт Backspace по одному. Клавиши, нажатые за это время, уже в окне, и Backspace стирает их вместо нашего слова, а Corrector их не видит (`_injecting`). Тест `v1.0.2 naive` это воспроизводит.
   Теперь: `gate.begin()` в хуке → следующие живые нажатия глушатся и копятся → замена одним `SendInput` → очередь переигрывается с меткой REPLAY и проходит через Corrector. Порядок сохраняется. Предохранитель: дольше 250 мс клавиши не держим.
2. **RU/EN.** pynput берёт раскладку своего потока, а не окна в фокусе. `translate(vk, scan, hkl)` считает символ по раскладке окна (ToUnicodeEx). Смена раскладки посреди слова — `break_context()`. Вывод замены идёт юникодом (`KEYEVENTF_UNICODE`), так что от раскладки не зависит.
3. **Пароли.** `ES_PASSWORD` / `EM_GETPASSWORDCHAR` + UIA `IsPassword`.
4. **Чёрный список.** IDE, терминалы, игровые клиенты, менеджеры паролей + любой полноэкранный процесс, кроме браузеров/офиса/мессенджеров. Свой список: `blacklist.txt` рядом с exe (`MyGame.exe` добавить, `-cmd.exe` убрать).

## Простой API
`should_skip() -> bool` — пароль, blacklist.txt, fullscreen-игра, смена раскладки. Если True — `core.break_context()` и пропустить клавишу. Без Windows всегда False. Всё ниже про очередь при быстрой печати — теория, на Windows не гонялось.

## Как подключить в main.py (это делает (5))
```python
from win_guard import WinGuard, WM_KEYDOWN, WM_SYSKEYDOWN, LLKHF_INJECTED
self.guard = WinGuard(os.path.join(app_dir(), "blacklist.txt"))   # в __init__

def _win_filter(self, msg, data):
    g = self.guard
    if not self.is_active or g.is_ours(data):
        return True                              # своё — мимо Corrector
    if g.hold_if_busy(msg, data):                # идёт замена — в очередь
        self.listener.suppress_event()
    if data.flags & LLKHF_INJECTED and not g.is_replay(data):
        return True                              # чужой софт инжектит
    if msg not in (WM_KEYDOWN, WM_SYSKEYDOWN):
        return True
    reason, hkl = g.context()
    if reason:                                   # пароль / IDE / игра
        with self.lock: self.core.break_context()
        return True
    if g.layout.changed(hkl):
        with self.lock: self.core.break_context()
    # дальше — то, что сейчас в _on_press, но символ берём так:
    #   ch = g.translate(data.vkCode, data.scanCode, hkl)
    # и Enter как сейчас. Если action есть:
    #   g.gate.begin()                          # ВАЖНО: тут, в хуке
    #   threading.Thread(target=g.replace, args=(erase, text), daemon=True).start()
    #   для Enter: replace(erase - 1, text) + suppress_event(), как в v1.0.2
    return True
```
- `_on_press` тогда оставить только для модификаторов (`held`), а логику символов перенести в фильтр (там есть vk/scan и dwExtraInfo).
- `_apply` и `_injecting` больше не нужны: наши события узнаём по `dwExtraInfo == EXTRA_OURS`.
- `_on_click` → `break_context()` оставить.
- Ctrl+Z (слот 4): откат тоже отправлять через `guard.replace(...)`, чтобы не терялись клавиши.

## CI
В `build-exe.yml` после `python test_core.py` добавить шаг `python test_win_guard.py`. На windows-latest он заодно проверит, что ctypes-часть импортируется.

## Что проверить руками на Windows
Быстро печатать «приет как дела» в Блокноте и Telegram, переключать RU/EN, вводить пароль в Windows-диалоге и на сайте (с comtypes), открыть VS Code / cmd / игру на весь экран — правок быть не должно.

## Стык с ui.py (4) — перекрёстная проверка (3)
1. **Одна точка входа для замены.** Оставить `app._apply(erase, text)`, но внутри звать `self.guard.replace(erase, text)`. Тогда обёртка (4) `_apply` (запись для Ctrl+Z) продолжит работать. `gate.begin()` — в хуке, ДО запуска потока с `app._apply`.
2. **Наши события не трогают undo/tail.** Без `_injecting` наши SendInput-события доходят до `_on_press` (и ui.py, и main) и сбрасывают undo через `touch()`. В фильтре: `app._last_ours = guard.is_ours(data)`, а в `_on_press` (main и ui) — `if app._injecting or getattr(app, "_last_ours", False): return`.
3. **Ctrl+Z.** `gate.begin()` звать прямо в `win32_event_filter` перед `dispatch("undo")`: dispatch идёт через `root.after`, и клавиши, нажатые до того, как tk дойдёт до отката, иначе попадут в окно раньше Backspace.
