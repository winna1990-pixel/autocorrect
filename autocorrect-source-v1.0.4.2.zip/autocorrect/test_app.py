"""Склейка v1.0.3 без Windows/tk/pynput: python test_app.py

Симулирует хук Windows: win32_event_filter main.py + ui.py (Ctrl+Z) + WinGuard
(кодер 3) с подменённым SendInput. Быстрая печать во время замены, Backspace-
и Ctrl+Z-отмена, пароль/смена раскладки, живые галочки, запасная иконка трея.
"""
import logging
import os
import sys
import tempfile
import threading
import time
import types

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
logging.disable(logging.CRITICAL)

import main  # noqa: E402
import ui  # noqa: E402
import win_guard as wg  # noqa: E402

fails = 0
total = 0


def check(name, got, want):
    global fails, total
    total += 1
    ok = got == want
    fails += not ok
    print(("OK  " if ok else "FAIL"), name, "" if ok else "| got=%r want=%r" % (got, want))


class K:  # фейковая клавиша pynput
    def __init__(self, name=None, char=None, vk=None):
        self.name, self.char, self.vk = name, char, vk

    def __hash__(self):
        return hash((self.name, self.char, self.vk))

    def __eq__(self, o):
        return isinstance(o, K) and (self.name, self.char, self.vk) == (o.name, o.char, o.vk)


KEY = types.SimpleNamespace(
    shift=K("shift"), shift_r=K("shift_r"), shift_l=K("shift_l"), caps_lock=K("caps_lock"),
    ctrl=K("ctrl"), ctrl_l=K("ctrl_l"), ctrl_r=K("ctrl_r"), alt=K("alt"), alt_l=K("alt_l"),
    alt_r=K("alt_r"), alt_gr=K("alt_gr"), space=K("space"), enter=K("enter"),
    backspace=K("backspace"), left=K("left"),
)
CTRL = KEY.ctrl_l


class Suppress(Exception):
    pass


class Listener:
    def suppress_event(self):
        raise Suppress()


class Data:
    def __init__(self, vk, scan=0, flags=0, extra=0):
        self.vkCode, self.scanCode, self.flags, self.dwExtraInfo = vk, scan, flags, extra


# Русская раскладка: vk -> символ (как вернул бы ToUnicodeEx)
LAYOUT = dict(zip(map(ord, "QWERTYUIOP"), "йцукенгшщз"))
LAYOUT.update(zip(map(ord, "ASDFGHJKL"), "фывапролд"))
LAYOUT.update(zip(map(ord, "ZXCVBNM"), "ячсмить"))
LAYOUT.update({0xDB: "х", 0xDD: "ъ", 0xBA: "ж", 0xDE: "э", 0xBC: "б", 0xBE: "ю", 0xBF: "."})
# v1.0.4: латиница и знаки ссылок — на свободных vk (в тесте раскладка не переключается)
_FREE_VK = list(range(0x30, 0x3A)) + list(range(0x60, 0x70)) + list(range(0xE9, 0xF6)) + [0xC1, 0xE1, 0xE3, 0xE4]
for _vk, _ch in zip(_FREE_VK, "htpsiebcxyzrua:/?=&@_12#3,"):
    LAYOUT[_vk] = _ch
VK_OF = {v: k for k, v in LAYOUT.items()}


class Sim:
    """Окно + хук. Пользовательские нажатия и наш SendInput идут через один фильтр."""

    def __init__(self, app):
        self.app = app
        self.screen = ""
        self.lock = threading.RLock()
        self.sent = []  # что ушло через SendInput: (erase, text)

    def _deliver(self, vk, scan, up, flags, extra, char=None):
        """Событие проходит хук. Возвращает True, если окно его получило."""
        with self.lock:  # очередь ввода Windows: события по одному
            return self._deliver_locked(vk, scan, up, flags, extra)

    def _deliver_locked(self, vk, scan, up, flags, extra):
        d = Data(vk, scan, flags, extra)
        msg = wg.WM_KEYUP if up else wg.WM_KEYDOWN
        try:
            res = self.app._win_filter(msg, d)
        except Suppress:
            return False
        if up:
            return True
        with self.lock:
            if vk == wg.VK_BACK:
                self.screen = self.screen[:-1]
            elif vk == wg.VK_RETURN:
                self.screen += "\n"
            elif vk == 0 and flags & wg.KEYEVENTF_UNICODE:
                self.screen += chr(scan)
            elif vk == 0x20:
                self.screen += " "
            elif vk in LAYOUT and not self.app.held:
                self.screen += LAYOUT[vk]
        if res is not False and not (flags & wg.LLKHF_INJECTED and extra == wg.EXTRA_OURS):
            key = (KEY.space if vk == 0x20 else KEY.enter if vk == wg.VK_RETURN
                   else KEY.backspace if vk == wg.VK_BACK else K(char=LAYOUT.get(vk), vk=vk))
            self.app._on_press(key)  # pynput-колбэк (обёртка ui.py)
        return True

    def send_events(self, plan):
        with self.lock:  # один SendInput — одна непрерывная пачка
            return self._send(plan)

    def _send(self, plan):
        for vk, scan, flags, extra in plan:
            self._deliver(vk, scan, bool(flags & wg.KEYEVENTF_KEYUP), flags | wg.LLKHF_INJECTED, extra)
        return len(plan)

    def type(self, text, flags=0, extra=0):
        for ch in text:
            vk = {" ": 0x20, "\n": wg.VK_RETURN, "\b": wg.VK_BACK}.get(ch) or VK_OF[ch]
            self._deliver(vk, 0, False, flags, extra)
            self._deliver(vk, 0, True, flags, extra)

    def ctrl(self, letter):
        self.app.held.add(CTRL)
        vk = ord(letter.upper())
        self._deliver(vk, 0, False, 0, 0)
        self._deliver(vk, 0, True, 0, 0)
        self.app.held.discard(CTRL)

    def settle(self):
        for _ in range(100):
            time.sleep(0.01)
            if not self.app.guard.gate.busy and threading.active_count() == 1:
                break
        time.sleep(0.02)


def make_app(context=("", 0x0419), **settings):
    path = os.path.join(tempfile.mkdtemp(), "settings.json")
    st = ui.Settings(path).load()
    for k, v in settings.items():
        st.set(k, v)
    guard = wg.WinGuard("")
    guard.context = lambda force=False: context
    guard.translate = lambda vk, scan, hkl: LAYOUT.get(vk, "")
    app = main.AutoCorrectApp.__new__(main.AutoCorrectApp)
    app.MODS = {KEY.shift, KEY.shift_l, KEY.shift_r, KEY.ctrl, KEY.ctrl_l, KEY.ctrl_r,
                KEY.alt, KEY.alt_l, KEY.alt_r, KEY.alt_gr, KEY.caps_lock}
    app.CTRL = {KEY.ctrl, KEY.ctrl_l, KEY.ctrl_r}
    app.ALT = {KEY.alt, KEY.alt_l, KEY.alt_r, KEY.alt_gr}
    app.Key = KEY
    app._init_state(st, guard)
    app.core.spell = main.get_spell_engine()
    app.listener = Listener()
    app.is_active = True
    sim = Sim(app)
    wg.send_events = sim.send_events  # SendInput -> симулятор
    ctl = ui.UIController(app, settings=st, autostart=ui.Autostart(registry=None), tray=False)
    ctl.wrap()
    return app, sim, ctl


# ---------- набор через хук
app, sim, ctl = make_app()
sim.type("приет как дела ")
sim.settle()
check("опечатка через SendInput", sim.screen, "Привет, как дела ")  # v1.0.4: запятая

# v1.0.4: ссылка с «?» держится до пробела и не меняется; вопрос — «?» на Enter
app, sim, ctl = make_app()
sim.type("ссылка https://site.ru/a?b=1&c=2 ты где")
sim.settle()
check("ссылка через хук не тронута", sim.screen, "Ссылка https://site.ru/a?b=1&c=2 ты где")
app, sim, ctl = make_app()
sim.type("превет, как дела ")
sim.settle()
check("задержанный токен — одна замена через хук", sim.screen, "Привет, как дела ")

app, sim, ctl = make_app()
sim.type("я знаю что ты тут ")
sim.settle()
check("запятая на слово позже (кодер 2)", sim.screen, "Я знаю, что ты тут ")

app, sim, ctl = make_app()
sim.type("ок\n")
sim.settle()
check("Enter: точка до Enter", sim.screen, "Ок.\n")
app, sim, ctl = make_app()
sim.type("ты где\n")
sim.settle()
check("Enter: вопрос — «?» до Enter", sim.screen, "Ты где?\n")
app, sim, ctl = make_app()
sim.type("превет, ок.\n")
sim.settle()
check("Enter: задержанная точка и опечатка до Enter", sim.screen, "Привет, ок.\n")

app, sim, ctl = make_app()
sim.type("каторый ")
sim.settle()
mid = sim.screen
sim.type("\b")
sim.settle()
check("Backspace-отмена через guard.replace", (mid, sim.screen), ("Который ", "каторый "))


# быстрая печать: клавиши во время замены уходят в очередь и не теряются
class SlowSim(Sim):
    once = True

    def _send(self, plan):
        if self.once and plan and plan[0][3] == wg.EXTRA_OURS:
            self.once = False
            # пока замена «идёт», пользователь успевает нажать ещё две клавиши
            self._deliver(VK_OF["к"], 0, False, 0, 0)
            self._deliver(VK_OF["а"], 0, False, 0, 0)
        return super()._send(plan)


app, sim, ctl = make_app()
slow = SlowSim(app)
wg.send_events = slow.send_events
slow.type("приет ")
slow.settle()
check("быстрая печать: очередь переиграна по порядку", slow.screen, "Привет ка")
slow.type("к ")
slow.settle()
check("быстрая печать: Corrector видел переигранные", app.core.buffer == "" and slow.screen.endswith("как "), True)

# ---------- Ctrl+Z (ui.py) поверх WinGuard
app, sim, ctl = make_app()
sim.type("приет ")
sim.settle()
check("Ctrl+Z доступен после замены", ctl.undo.can_undo(), True)
sim.ctrl("z")
sim.settle()
check("Ctrl+Z вернул набранное", sim.screen, "приет ")
check("Ctrl+Z одноразовый", ctl.undo.can_undo(), False)

app, sim, ctl = make_app()
sim.type("приет ")
sim.settle()
sim.type("к")
check("другая клавиша гасит Ctrl+Z", ctl.undo.can_undo(), False)

app, sim, ctl = make_app()
sim.type("приет ")
sim.settle()
now = [time.monotonic() + 6]
ctl.undo.clock = lambda: now[0]
check("Ctrl+Z через 6 с — обычный Ctrl+Z программы", ctl.undo.can_undo(), False)

app, sim, ctl = make_app()
sim.type("я знаю что ")
sim.settle()
check("Enter-замену Ctrl+Z не отменяет", (sim.type("\n") or sim.settle() or ctl.undo.can_undo()), False)

app, sim, ctl = make_app()
sim.type("приет ")
sim.settle()
app.held.add(CTRL)
res = app._win_filter(wg.WM_KEYDOWN, Data(0x5A, flags=wg.LLKHF_INJECTED, extra=wg.EXTRA_OURS))
app.held.discard(CTRL)
check("наш Z (EXTRA_OURS) раньше Ctrl+Z: не отмена", (res, ctl.undo.can_undo()), (False, True))

app, sim, ctl = make_app()
sim.type("каторый ")
sim.settle()
sim.type("\b")
sim.settle()
check("Backspace-отмена гасит Ctrl+Z (нет двойной отмены)", (sim.screen, ctl.undo.can_undo()), ("каторый ", False))

# ---------- should_skip: пароль, чёрный список, раскладка
app, sim, ctl = make_app(context=("password", 0x0419))
sim.type("приет как ")
sim.settle()
check("поле пароля: ничего не меняем", sim.screen, "приет как ")
app, sim, ctl = make_app(context=("blacklist", 0x0419))
sim.type("я знаю что ты ")
sim.settle()
check("чёрный список: ничего не меняем", sim.screen, "я знаю что ты ")

app, sim, ctl = make_app()
sim.type("при")
app.guard.context = lambda force=False: ("", 0x0409)
sim.type("ет ")
sim.settle()
check("смена раскладки посреди слова — разрыв", "Привет" in sim.screen, False)

app, sim, ctl = make_app()
res = app._win_filter(wg.WM_KEYDOWN, Data(VK_OF["п"], flags=wg.LLKHF_INJECTED, extra=0))
check("чужой инжект (экранная клавиатура, робот) = текст пользователя", (res, app.core.buffer), (True, "п"))

app, sim, ctl = make_app()
app._injecting = True  # наш Ctrl+C/Ctrl+V
res = app._win_filter(wg.WM_KEYDOWN, Data(VK_OF["п"], flags=wg.LLKHF_INJECTED, extra=0))
check("наш pynput-инжект (_injecting) не кормит Corrector", (res, app.core.buffer), (True, ""))

app, sim, ctl = make_app()
res = app._win_filter(wg.WM_KEYDOWN, Data(VK_OF["п"], flags=wg.LLKHF_INJECTED, extra=wg.EXTRA_OURS))
check("наша замена (EXTRA_OURS) не кормит Corrector", app.core.buffer, "")

import io
app, sim, ctl = make_app()
app._hook_log = io.StringIO()
sim.type("приет ")
sim.settle()
log = app._hook_log.getvalue()
check("журнал хука пишет нажатия и решения", ("kind=hw" in log, "kind=ours" in log, "decision=" in log), (True, True, True))
check("с журналом замена не ломается", "Привет" in sim.screen, True)

# ---------- e2e zero: робот печатает SendInput без метки (LLKHF_INJECTED, extra=0)
E2E = ["привет как дела\n", "превет каторый сигодня\n", "когда будешь дома напиши\n",
       "пока что подожди\n", "я знаю что ты прав\n", "вася иди сюда\n"]
# строка 6 e2e: ссылка + Enter — без точки (решение сценариста)
app, sim, ctl = make_app()
sim.type("ссылка https://site.ru/a?b=1\n", wg.LLKHF_INJECTED, 0)
sim.settle()
check("e2e стр.6: ссылка+Enter без точки", sim.screen, "Ссылка https://site.ru/a?b=1\n")
check("fix_text == живой набор для ссылки", main.fix_text("ссылка https://site.ru/a?b=1"), "Ссылка https://site.ru/a?b=1")

app, sim, ctl = make_app()
app.guard = None  # запасной путь без WinGuard
app.core.feed_char("д"); app.core.feed_char("а")
try:
    res = app._win_filter(wg.WM_KEYDOWN, Data(wg.VK_RETURN, flags=wg.LLKHF_INJECTED, extra=0))
except Suppress:
    res = "suppressed"
check("без WinGuard: Enter от экранной клавиатуры ставит точку", res, "suppressed")

for line in E2E:
    outs = []
    for flags, extra in ((0, 0), (wg.LLKHF_INJECTED, 0), (wg.LLKHF_INJECTED, wg.EXTRA_REPLAY)):
        app, sim, ctl = make_app()
        sim.type(line, flags, extra)
        sim.settle()
        outs.append(sim.screen)
    check("zero = живая клава = replay: " + line.strip(), outs[1] == outs[0] == outs[2] and outs[0] != line, True)

app, sim, ctl = make_app()
app.is_active = False
sim.type("приет ")
check("выключено: ничего не трогаем", sim.screen, "приет ")

# ---------- живые галочки
app, sim, ctl = make_app()
app.settings.set("commas", False)
sim.type("я знаю что ты ")
sim.settle()
check("галочка «Запятые» сразу", sim.screen, "Я знаю что ты ")
app.settings.set("spelling", False)
sim.type("приет ")
sim.settle()
check("галочка «Орфография» сразу", sim.screen.endswith("приет "), True)
app.settings.set("pause_period", False)
check("галочка «Точка после паузы»", (app.core.pause_period, app.core.double_space), (False, False))
check("fix_text не зависит от галочек окна", main.fix_text("я знаю что ты"), "Я знаю, что ты.")

# ---------- настройки
p = os.path.join(tempfile.mkdtemp(), "x", "settings.json")
s = main.SimpleSettings(p).load()
check("SimpleSettings: те же ключи, что ui", sorted(s.data), sorted(ui.DEFAULTS))
s.set("commas", False)
check("SimpleSettings: сохранение", main.SimpleSettings(p).load()["commas"], False)
check("open_settings берёт ui.Settings", type(main.open_settings(p)).__name__, "Settings")

# ---------- иконка трея
img = ui.load_icon_image(True)
try:
    import PIL  # noqa: F401
    has_pil = True
except ImportError:
    has_pil = False
check("assets/icon_64.png найден", bool(ui.resource_path(ui.ICON_FILE)), True)
if has_pil:
    check("иконка из файла 64x64", img.size, (64, 64))
    gray = ui.load_icon_image(False)
    px = gray.getpixel((32, 32))
    check("выключено — серая", px[0] == px[1] == px[2], True)
    check("нет файла — запасная иконка", ui.load_icon_image(True, path="/нет/icon.png").size, (64, 64))
    bad = os.path.join(tempfile.mkdtemp(), "broken.png")
    with open(bad, "wb") as f:
        f.write(b"not a png")
    check("битый файл — запасная иконка", ui.load_icon_image(True, path=bad).size, (64, 64))

saved = {k: sys.modules.get(k) for k in ("PIL", "pystray")}
sys.modules["PIL"] = None  # Pillow «не установлен»
try:
    check("нет файла и нет Pillow — None, без падения", ui.load_icon_image(True, path="/нет/icon.png"), None)
    fake = types.ModuleType("pystray")
    fake.Icon = lambda *a, **k: (_ for _ in ()).throw(AssertionError("не должны звать"))
    sys.modules["pystray"] = fake
    old_file = ui.ICON_FILE
    ui.ICON_FILE = os.path.join("assets", "нет.png")
    ctl_stub = types.SimpleNamespace(is_active=lambda: True, settings=ui.Settings(p).load(),
                                     undo=ui.UndoTracker())
    check("трей без иконки не стартует и не падает", ui.TrayIcon(ctl_stub).start(), False)
    ui.ICON_FILE = old_file
finally:
    for k, v in saved.items():
        if v is None:
            sys.modules.pop(k, None)
        else:
            sys.modules[k] = v

print("\nИТОГО: %d/%d пройдено" % (total - fails, total))
sys.exit(1 if fails else 0)
