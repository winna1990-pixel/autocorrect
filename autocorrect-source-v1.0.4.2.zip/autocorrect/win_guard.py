"""
win_guard.py — стабильность замены на Windows (vitaa_games, кодер 3).

Что даёт main.py:
  1. Ничего не теряется при быстрой печати:
     - замена (Backspace×N + текст) уходит ОДНИМ вызовом SendInput,
       пользовательские нажатия не могут вклиниться внутрь;
     - клавиши, нажатые пока замена в работе, глушатся в хуке, копятся
       в очереди и после замены переигрываются в том же порядке
       (и при этом проходят через Corrector, буфер не рвётся).
  2. Раскладка RU/EN: символ считается через ToUnicodeEx по раскладке
     окна в фокусе (pynput берёт раскладку своего потока, отсюда
     «ghbdtn» вместо «привет»). Смена раскладки посреди слова = разрыв
     контекста.
  3. Поля паролей не трогаем (ES_PASSWORD у Win32 Edit, UIA IsPassword,
     если стоит comtypes).
  4. Чёрный список приложений: IDE, терминалы, игры (+ любой
     полноэкранный процесс не из белого списка) + blacklist.txt рядом с exe.

Чистая логика (очередь, чёрный список, раскладка, сборка INPUT)
тестируется без Windows: python test_win_guard.py
"""

import os
import sys
import threading
import time

IS_WIN = sys.platform == "win32"

# Метка в dwExtraInfo, чтобы хук отличал наши события от чужих.
EXTRA_OURS = 0x5643_0001     # наша замена — хук пропускает и не кормит Corrector
EXTRA_REPLAY = 0x5643_0002   # переигранная клавиша пользователя — кормить Corrector

WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, WM_SYSKEYUP = 0x0100, 0x0101, 0x0104, 0x0105
LLKHF_INJECTED = 0x10
VK_BACK, VK_RETURN, VK_SHIFT, VK_CONTROL, VK_MENU, VK_CAPITAL = 0x08, 0x0D, 0x10, 0x11, 0x12, 0x14
INPUT_KEYBOARD = 1
KEYEVENTF_KEYUP, KEYEVENTF_UNICODE = 0x0002, 0x0004

# ---------------------------------------------------------------- чёрный список

DEFAULT_BLACKLIST = {
    # IDE / редакторы кода
    "code.exe", "code - insiders.exe", "cursor.exe", "devenv.exe", "idea64.exe",
    "idea.exe", "pycharm64.exe", "pycharm.exe", "webstorm64.exe", "clion64.exe",
    "rider64.exe", "goland64.exe", "phpstorm64.exe", "datagrip64.exe",
    "studio64.exe", "sublime_text.exe", "notepad++.exe", "atom.exe", "zed.exe",
    "vim.exe", "gvim.exe", "nvim.exe", "nvim-qt.exe", "emacs.exe", "unity.exe",
    "godot.exe", "ue4editor.exe", "unrealeditor.exe",
    # терминалы
    "cmd.exe", "powershell.exe", "pwsh.exe", "powershell_ise.exe",
    "windowsterminal.exe", "wt.exe", "conhost.exe", "openconsole.exe",
    "mintty.exe", "putty.exe", "kitty.exe", "alacritty.exe", "wezterm-gui.exe",
    "conemu64.exe", "conemu.exe", "cmder.exe", "hyper.exe", "tabby.exe",
    "mobaxterm.exe", "bash.exe", "wsl.exe",
    # игровые клиенты / античиты (сами игры ловим ещё и по fullscreen)
    "steam.exe", "steamwebhelper.exe", "epicgameslauncher.exe",
    "battle.net.exe", "riotclientux.exe", "leagueclientux.exe",
    "league of legends.exe", "valorant-win64-shipping.exe", "cs2.exe",
    "csgo.exe", "dota2.exe", "minecraft.exe", "javaw.exe", "gta5.exe",
    "fortniteclient-win64-shipping.exe", "r5apex.exe", "overwatch.exe",
    "robloxplayerbeta.exe", "eldenring.exe", "witcher3.exe",
    # менеджеры паролей
    "keepass.exe", "keepassxc.exe", "1password.exe", "bitwarden.exe",
}

# Полноэкранные, но это не игры — по fullscreen не выключаем.
FULLSCREEN_OK = {
    "explorer.exe", "chrome.exe", "msedge.exe", "firefox.exe", "opera.exe",
    "browser.exe", "yandex.exe", "telegram.exe", "discord.exe", "winword.exe",
    "excel.exe", "powerpnt.exe", "onenote.exe", "outlook.exe", "notepad.exe",
    "wordpad.exe", "slack.exe", "teams.exe", "ms-teams.exe", "whatsapp.exe",
    "viber.exe", "obsidian.exe", "notion.exe", "soffice.bin", "applicationframehost.exe",
}


def norm_exe(path: str) -> str:
    return os.path.basename((path or "").replace("/", "\\").split("\\")[-1]).strip().lower()


def load_list(path: str) -> set:
    """blacklist.txt: по exe в строке, # — комментарий, '-name.exe' — убрать из стандартного."""
    add, remove = set(), set()
    if path and os.path.exists(path):
        with open(path, "r", encoding="utf-8-sig") as f:
            for raw in f:
                line = raw.split("#", 1)[0].strip()
                if not line:
                    continue
                if line.startswith("-"):
                    remove.add(norm_exe(line[1:]))
                else:
                    add.add(norm_exe(line))
    return add, remove


def build_blacklist(path: str = "") -> set:
    add, remove = load_list(path)
    base = set() if (path and os.path.exists(path)) else DEFAULT_BLACKLIST
    return (base | add) - remove


def is_fullscreen(win_rect, mon_rect) -> bool:
    """rect = (left, top, right, bottom). Окно закрывает весь монитор."""
    if not win_rect or not mon_rect:
        return False
    wl, wt, wr, wb = win_rect
    ml, mt, mr, mb = mon_rect
    return wl <= ml and wt <= mt and wr >= mr and wb >= mb and (mr - ml) > 0


def skip_reason(exe: str, blacklist: set, fullscreen: bool, password: bool) -> str:
    """'' — можно править; иначе причина, почему нельзя."""
    exe = norm_exe(exe)
    if password:
        return "password"
    if exe in blacklist:
        return "blacklist"
    if fullscreen and exe and exe not in FULLSCREEN_OK:
        return "fullscreen"
    return ""

# ---------------------------------------------------------------- раскладка

LANG_RU = {0x0419, 0x0422, 0x0423}  # ru, uk, be — кириллица
LANG_EN = {0x0409, 0x0809, 0x1009, 0x0C09, 0x1409, 0x4009}


def layout_lang(hkl: int) -> str:
    langid = (hkl or 0) & 0xFFFF
    if langid in LANG_RU:
        return "ru"
    if langid in LANG_EN:
        return "en"
    return "other" if langid else ""


class LayoutTracker:
    """Сообщает, сменилась ли раскладка с прошлого символа (→ break_context)."""

    def __init__(self):
        self.last = None

    def changed(self, hkl: int) -> bool:
        prev, self.last = self.last, hkl
        return prev is not None and prev != hkl

    def reset(self):
        self.last = None

# ---------------------------------------------------------------- очередь

class KeyGate:
    """Пока замена в работе, живые нажатия копятся тут, а не уходят в окно.

    Хук (поток pynput):   if gate.offer(event): suppress
    Воркер замены:        gate.begin() ... send ... queued = gate.end(); replay(queued)
    begin() надо звать ещё в хуке, в момент, когда решили менять, — тогда
    следующая же клавиша гарантированно попадёт в очередь.
    """

    MAX_HOLD = 0.25  # сек: дольше не держим, даже если воркер завис

    def __init__(self, clock=time.monotonic):
        self._lock = threading.Lock()
        self._busy_since = None
        self._queue = []
        self.clock = clock

    @property
    def busy(self) -> bool:
        with self._lock:
            return self._busy_locked()

    def _busy_locked(self):
        if self._busy_since is None:
            return False
        if self.clock() - self._busy_since > self.MAX_HOLD:
            return False  # предохранитель: не глотаем клавиши вечно
        return True

    def begin(self):
        with self._lock:
            self._busy_since = self.clock()

    def offer(self, event) -> bool:
        """True — событие забрали в очередь (в хуке его надо подавить)."""
        with self._lock:
            if not self._busy_locked():
                return False
            self._queue.append(event)
            return True

    def end(self) -> list:
        with self._lock:
            q, self._queue = self._queue, []
            self._busy_since = None
            return q

# ---------------------------------------------------------------- сборка INPUT

def plan_replace(erase: int, text: str, extra: int = EXTRA_OURS):
    """Список событий для одного SendInput: (vk, scan, flags, extra).

    Backspace×erase, потом текст юникодом (не зависит от раскладки),
    '\\n' — настоящий VK_RETURN (мессенджеры шлют сообщение по нему).
    """
    out = []
    for _ in range(max(0, erase)):
        out.append((VK_BACK, 0, 0, extra))
        out.append((VK_BACK, 0, KEYEVENTF_KEYUP, extra))
    for ch in text:
        if ch == "\n":
            out.append((VK_RETURN, 0, 0, extra))
            out.append((VK_RETURN, 0, KEYEVENTF_KEYUP, extra))
            continue
        b = ch.encode("utf-16-le")
        for i in range(0, len(b), 2):  # суррогатные пары (эмодзи) — по юниту
            unit = int.from_bytes(b[i:i + 2], "little")
            out.append((0, unit, KEYEVENTF_UNICODE, extra))
            out.append((0, unit, KEYEVENTF_UNICODE | KEYEVENTF_KEYUP, extra))
    return out


def plan_replay(events, extra: int = EXTRA_REPLAY):
    """Переиграть пойманные нажатия как есть (vk/scan), с меткой REPLAY."""
    out = []
    for ev in events:
        vk, scan, up = ev["vk"], ev.get("scan", 0), ev.get("up", False)
        out.append((vk, scan, KEYEVENTF_KEYUP if up else 0, extra))
    return out

# ---------------------------------------------------------------- Windows API

if IS_WIN:
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    ULONG_PTR = ctypes.c_size_t

    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD),
                    ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD),
                    ("dwExtraInfo", ULONG_PTR)]

    class MOUSEINPUT(ctypes.Structure):
        _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG),
                    ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                    ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

    class _U(ctypes.Union):
        _fields_ = [("ki", KEYBDINPUT), ("mi", MOUSEINPUT)]

    class INPUT(ctypes.Structure):
        _anonymous_ = ("u",)
        _fields_ = [("type", wintypes.DWORD), ("u", _U)]

    class GUITHREADINFO(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("flags", wintypes.DWORD),
                    ("hwndActive", wintypes.HWND), ("hwndFocus", wintypes.HWND),
                    ("hwndCapture", wintypes.HWND), ("hwndMenuOwner", wintypes.HWND),
                    ("hwndMoveSize", wintypes.HWND), ("hwndCaret", wintypes.HWND),
                    ("rcCaret", wintypes.RECT)]

    class MONITORINFO(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT),
                    ("rcWork", wintypes.RECT), ("dwFlags", wintypes.DWORD)]

    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.SendInput.argtypes = (wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int)
    user32.GetWindowThreadProcessId.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.DWORD))
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD
    user32.GetKeyboardLayout.argtypes = (wintypes.DWORD,)
    user32.GetKeyboardLayout.restype = ctypes.c_void_p
    user32.ToUnicodeEx.argtypes = (wintypes.UINT, wintypes.UINT, ctypes.POINTER(ctypes.c_ubyte),
                                   wintypes.LPWSTR, ctypes.c_int, wintypes.UINT, ctypes.c_void_p)
    user32.GetWindowLongW.argtypes = (wintypes.HWND, ctypes.c_int)
    user32.GetWindowLongW.restype = wintypes.LONG
    user32.SendMessageTimeoutW.argtypes = (wintypes.HWND, wintypes.UINT, wintypes.WPARAM,
                                           wintypes.LPARAM, wintypes.UINT, wintypes.UINT,
                                           ctypes.POINTER(ULONG_PTR))
    user32.MonitorFromWindow.restype = ctypes.c_void_p
    user32.MonitorFromWindow.argtypes = (wintypes.HWND, wintypes.DWORD)
    user32.GetMonitorInfoW.argtypes = (ctypes.c_void_p, ctypes.POINTER(MONITORINFO))
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.QueryFullProcessImageNameW.argtypes = (wintypes.HANDLE, wintypes.DWORD,
                                                    wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD))

    def send_events(plan) -> int:
        """Один атомарный SendInput на весь план."""
        if not plan:
            return 0
        arr = (INPUT * len(plan))()
        for i, (vk, scan, flags, extra) in enumerate(plan):
            arr[i].type = INPUT_KEYBOARD
            arr[i].ki = KEYBDINPUT(vk, scan, flags, 0, extra)
        return user32.SendInput(len(plan), arr, ctypes.sizeof(INPUT))

    def _exe_of_pid(pid: int) -> str:
        h = kernel32.OpenProcess(0x1000, False, pid)  # QUERY_LIMITED_INFORMATION
        if not h:
            return ""
        try:
            buf = ctypes.create_unicode_buffer(1024)
            n = wintypes.DWORD(1024)
            if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)):
                return buf.value
            return ""
        finally:
            kernel32.CloseHandle(h)

    def foreground():
        """(hwnd, focus_hwnd, exe, thread_id, hkl)"""
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return (None, None, "", 0, 0)
        pid = wintypes.DWORD()
        tid = user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        gti = GUITHREADINFO(cbSize=ctypes.sizeof(GUITHREADINFO))
        focus = hwnd
        if user32.GetGUIThreadInfo(tid, ctypes.byref(gti)) and gti.hwndFocus:
            focus = gti.hwndFocus
        hkl = user32.GetKeyboardLayout(tid) or 0
        return (hwnd, focus, _exe_of_pid(pid.value), tid, hkl)

    def window_fullscreen(hwnd) -> bool:
        r = wintypes.RECT()
        if not hwnd or not user32.GetWindowRect(hwnd, ctypes.byref(r)):
            return False
        mon = user32.MonitorFromWindow(hwnd, 2)
        mi = MONITORINFO(cbSize=ctypes.sizeof(MONITORINFO))
        if not mon or not user32.GetMonitorInfoW(mon, ctypes.byref(mi)):
            return False
        m = mi.rcMonitor
        return is_fullscreen((r.left, r.top, r.right, r.bottom), (m.left, m.top, m.right, m.bottom))

    ES_PASSWORD, GWL_STYLE, EM_GETPASSWORDCHAR = 0x20, -16, 0x00D2

    def _uia_is_password() -> bool:
        """Браузеры, WPF, UWP: UI Automation (нужен comtypes; нет — пропускаем)."""
        try:
            import comtypes.client  # noqa
            from comtypes.gen.UIAutomationClient import CUIAutomation, IUIAutomation  # noqa
        except Exception:
            try:
                import comtypes.client
                comtypes.client.GetModule("UIAutomationCore.dll")
                from comtypes.gen.UIAutomationClient import CUIAutomation, IUIAutomation
            except Exception:
                return False
        try:
            uia = comtypes.client.CreateObject(CUIAutomation, interface=IUIAutomation)
            el = uia.GetFocusedElement()
            return bool(el and el.CurrentIsPassword)
        except Exception:
            return False

    def focus_is_password(focus_hwnd) -> bool:
        if focus_hwnd:
            style = user32.GetWindowLongW(focus_hwnd, GWL_STYLE)
            cls = ctypes.create_unicode_buffer(64)
            user32.GetClassNameW(focus_hwnd, cls, 64)
            name = cls.value.lower()
            if ("edit" in name) and (style & ES_PASSWORD):
                return True
            res = ULONG_PTR(0)
            if "edit" in name and user32.SendMessageTimeoutW(
                    focus_hwnd, EM_GETPASSWORDCHAR, 0, 0, 0x2, 30, ctypes.byref(res)) and res.value:
                return True
        return _uia_is_password()

    def char_from_vk(vk: int, scan: int, hkl) -> str:
        """Символ по раскладке окна в фокусе. '' — не печатный/мёртвая клавиша."""
        state = (ctypes.c_ubyte * 256)()
        for k in (VK_SHIFT, VK_CONTROL, VK_MENU, 0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5):
            if user32.GetAsyncKeyState(k) & 0x8000:
                state[k] = 0x80
        if user32.GetKeyState(VK_CAPITAL) & 1:
            state[VK_CAPITAL] = 0x01
        buf = ctypes.create_unicode_buffer(8)
        # флаг 0x4: не портить состояние мёртвых клавиш (Win10 1607+)
        n = user32.ToUnicodeEx(vk, scan, state, buf, 8, 0x4, hkl)
        if n <= 0:
            return ""
        s = buf.value[:n]
        return s if s.isprintable() else ""
else:
    def send_events(plan) -> int:  # не Windows — заглушки, чтобы импорт не падал
        return 0

    def foreground():
        return (None, None, "", 0, 0)

    def window_fullscreen(hwnd) -> bool:
        return False

    def focus_is_password(focus_hwnd) -> bool:
        return False

    def char_from_vk(vk, scan, hkl) -> str:
        return ""

# ---------------------------------------------------------------- фасад для main.py

class WinGuard:
    """Всё в одном. Пример подключения — CODER3_WIN_GUARD.md."""

    CACHE = 0.2  # сек: окно/фокус перепроверяем не чаще

    def __init__(self, blacklist_path: str = ""):
        self.blacklist = build_blacklist(blacklist_path)
        self.gate = KeyGate()
        self.layout = LayoutTracker()
        self._cache_t = 0.0
        self._cache = ("", 0, None)  # (reason, hkl, hwnd)

    def context(self, force=False):
        """(reason, hkl). reason != '' — сейчас ничего не правим."""
        now = time.monotonic()
        if force or now - self._cache_t > self.CACHE:
            hwnd, focus, exe, _tid, hkl = foreground()
            if hwnd != self._cache[2]:
                self.layout.reset()
            reason = skip_reason(exe, self.blacklist, window_fullscreen(hwnd), focus_is_password(focus))
            self._cache = (reason, hkl, hwnd)
            self._cache_t = now
        return self._cache[0], self._cache[1]

    @staticmethod
    def is_ours(data) -> bool:
        return getattr(data, "dwExtraInfo", 0) == EXTRA_OURS

    @staticmethod
    def is_replay(data) -> bool:
        return getattr(data, "dwExtraInfo", 0) == EXTRA_REPLAY

    def hold_if_busy(self, msg, data) -> bool:
        """В win32_event_filter: True — событие ушло в очередь, его надо подавить."""
        # Переигранные (REPLAY) тоже держим: если переигранная клавиша сама
        # запустила новую замену (gate.begin), хвост переигрывания должен
        # подождать её, иначе Backspace'ы новой замены сотрут не то (v1.0.3).
        if self.is_ours(data):
            return False
        if msg not in (WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, WM_SYSKEYUP):
            return False
        return self.gate.offer({"vk": data.vkCode, "scan": data.scanCode,
                                "up": msg in (WM_KEYUP, WM_SYSKEYUP)})

    def translate(self, vk: int, scan: int, hkl) -> str:
        return char_from_vk(vk, scan, hkl)

    def replace(self, erase: int, text: str):
        """Звать из воркера ПОСЛЕ gate.begin() (его делают в хуке)."""
        try:
            send_events(plan_replace(erase, text))
        finally:
            queued = self.gate.end()
            if queued:
                send_events(plan_replay(queued))


# ---------------------------------------------------------------- простой API для (5)

_HERE = os.path.dirname(os.path.abspath(__file__))
_default_guard = None


def should_skip() -> bool:
    """True — сейчас не правим: поле пароля, exe из blacklist.txt, полноэкранная игра
    или раскладка сменилась с прошлого вызова (тогда надо break_context)."""
    global _default_guard
    if _default_guard is None:
        _default_guard = WinGuard(os.path.join(_HERE, "blacklist.txt"))
    reason, hkl = _default_guard.context()
    return bool(reason) or _default_guard.layout.changed(hkl)
