"""Тесты интерфейса (кодер 4): python test_ui.py
Не нужны ни pynput, ни pystray, ни tk, ни Windows."""
import os
import sys
import tempfile
import threading

HERE = os.path.dirname(os.path.abspath(__file__))
for cand in (HERE, os.path.join(HERE, "..", "..", "fixed")):
    if os.path.exists(os.path.join(cand, "main.py")):
        sys.path.insert(0, os.path.abspath(cand))
        break
sys.path.insert(0, HERE)

import main  # noqa: E402
import ui as ui  # noqa: E402

DICT = os.path.join(os.path.dirname(main.__file__), "dictionary.txt")
FIXES, NAMES = main.load_dictionary(DICT)
Flagged = ui.make_flagged_corrector(main.Corrector)
fails = 0


def check(name, got, want):
    global fails
    ok = got == want
    if not ok:
        fails += 1
    print(("OK  " if ok else "FAIL"), name, "" if ok else "| got=%r want=%r" % (got, want))


def tmp_settings(**over):
    path = os.path.join(tempfile.mkdtemp(), "s", "settings.json")
    s = ui.Settings(path).load()
    for k, v in over.items():
        s.set(k, v)
    return s


def type_text(core, text):
    out = ""
    for ch in text:
        out += ch
        a = core.feed_enter() if ch == "\n" else core.feed_space() if ch == " " else core.feed_char(ch)
        if a:
            out = out[: len(out) - a[0]] + a[1]
    return out


# ---------- Settings
s = tmp_settings()
check("defaults", (s["commas"], s["spelling"], s["pause_period"], s["autostart"]), (True, True, True, False))
s.set("commas", False)
s2 = ui.Settings(s.path).load()
check("save/load round-trip", s2["commas"], False)
with open(s.path, "w", encoding="utf-8") as f:
    f.write("{битый json")
check("broken json -> defaults", ui.Settings(s.path).load()["commas"], True)
with open(s.path, "w", encoding="utf-8") as f:
    f.write('{"commas": "yes", "hotkey_toggle": "a", "lol": 1}')
s3 = ui.Settings(s.path).load()
check("wrong types ignored", s3["commas"], True)
check("bad hotkey -> default", s3["hotkey_toggle"], ui.DEFAULT_HOTKEY)
seen = []
s3.on_change(lambda k, v: seen.append((k, v)))
s3.toggle("spelling")
s3.set("spelling", False)  # то же значение: без события
check("on_change once", seen, [("spelling", False)])

# ---------- ядро с галочками
sample_comma = "я знаю что ты тут "
base = type_text(main.Corrector(FIXES, NAMES), sample_comma)
check("commas ON same as core", type_text(Flagged(FIXES, NAMES, tmp_settings()), sample_comma), base)
check("commas OFF", ", что" in type_text(Flagged(FIXES, NAMES, tmp_settings(commas=False)), sample_comma), False)

wrong = next(iter(FIXES)) if FIXES else None
if wrong:
    t = "ну " + wrong + " "
    on = type_text(Flagged(FIXES, NAMES, tmp_settings()), t)
    off = type_text(Flagged(FIXES, NAMES, tmp_settings(spelling=False)), t)
    check("spelling ON fixes", FIXES[wrong] in on, True)
    check("spelling OFF keeps word", wrong in off, True)
    check("spelling OFF still capitalizes", off[:1], "Н")
    st = tmp_settings()
    core = Flagged(FIXES, NAMES, st)
    st.set("spelling", False)
    core.apply_settings()
    check("spelling live toggle", wrong in type_text(core, t), True)

check("pause_period ON", type_text(Flagged(FIXES, NAMES, tmp_settings()), "привет  как "), "Привет. Как ")
check("pause_period OFF", type_text(Flagged(FIXES, NAMES, tmp_settings(pause_period=False)), "привет  как "), "Привет  как ")
check("no settings = core", type_text(Flagged(FIXES, NAMES), "привет  как "), "Привет. Как ")
check("enter dot untouched by pause_period", type_text(Flagged(FIXES, NAMES, tmp_settings(pause_period=False)), "ок\n"), "Ок.\n")

# ---------- Undo
clock = [0.0]
u = ui.UndoTracker(timeout=5, clock=lambda: clock[0])
check("empty undo", u.take(), None)
u.record("превед ", "Привет ")
check("can undo", u.can_undo(), True)
check("undo action", u.take(), (7, "превед "))
check("undo one-shot", u.take(), None)
u.record("а", "а")
check("no-op not recorded", u.can_undo(), False)
u.record("x ", "X ")
clock[0] = 6
check("undo timeout", u.take(), None)
clock[0] = 0
u.record("x ", "X ")
u.touch()
check("undo cleared by key", u.can_undo(), False)

tt = ui.TypedTail(size=8)
for ch in "абвгдежзик":
    tt.push(ch)
check("tail ring", tt.text, "вгдежзик")
tt.backspace()
tt.replace_tail(2, "XY ")
check("tail replace", tt.text, "вгдежXY ")

# ---------- hotkey
check("parse default", ui.parse_hotkey("<ctrl>+<alt>+<space>"), (frozenset({"ctrl", "alt"}), "space"))
check("parse plain", ui.parse_hotkey("Ctrl+Shift+F12"), (frozenset({"ctrl", "shift"}), "f12"))
check("reject no modifier", ui.parse_hotkey("a"), None)
check("reject two keys", ui.parse_hotkey("<ctrl>+a+b"), None)
check("reject junk", ui.parse_hotkey("<ctrl>+<lol>"), None)
check("format", ui.format_hotkey("<ctrl>+<alt>+<space>"), "Ctrl+Alt+Space")
check("format letter", ui.format_hotkey("<ctrl>+<shift>+k"), "Ctrl+Shift+K")


class K:  # фейковая клавиша pynput
    def __init__(self, name=None, char=None, vk=None):
        self.name, self.char, self.vk = name, char, vk

    def __hash__(self):
        return hash((self.name, self.char, self.vk))

    def __eq__(self, o):
        return isinstance(o, K) and (self.name, self.char, self.vk) == (o.name, o.char, o.vk)


CTRL, ALT, SHIFT = K("ctrl_l"), K("alt_l"), K("shift")
m = ui.HotkeyMatcher()
check("match ctrl+alt+space", m.matches(*ui.normalize_pynput(K("space"), {CTRL, ALT})), True)
check("no match ctrl+space", m.matches(*ui.normalize_pynput(K("space"), {CTRL})), False)
check("no match extra shift", m.matches(*ui.normalize_pynput(K("space"), {CTRL, ALT, SHIFT})), False)
check("ctrl+z via vk", ui.normalize_pynput(K(char="\x1a", vk=0x5A), {CTRL}), ({"ctrl"}, "z"))

hits = []
hl = ui.HotkeyListener(m, lambda: hits.append(1))
hl.handle_press(CTRL); hl.handle_press(ALT); hl.handle_press(K("space"))
hl.handle_release(ALT); hl.handle_press(K("space"))
check("HotkeyListener fires once", hits, [1])


# ---------- автозапуск
class FakeReg:
    def __init__(self):
        self.d = {}

    def read(self, p, n):
        return self.d.get((p, n))

    def write(self, p, n, v):
        self.d[(p, n)] = v

    def delete(self, p, n):
        self.d.pop((p, n), None)


reg = FakeReg()
a = ui.Autostart(registry=reg)
check("autostart off", a.is_enabled(), False)
a.sync(True, '"C:\\AC\\AutoCorrect.exe" --minimized')
check("autostart on", reg.read(ui.RUN_KEY, "AutoCorrect"), '"C:\\AC\\AutoCorrect.exe" --minimized')
a.sync(True, '"D:\\new\\AutoCorrect.exe" --minimized')
check("autostart path updated", reg.read(ui.RUN_KEY, "AutoCorrect"), '"D:\\new\\AutoCorrect.exe" --minimized')
a.sync(False)
check("autostart removed", a.is_enabled(), False)
check("no registry on linux", ui.Autostart(registry=None).enable("x") if sys.platform != "win32" else False, False)
check("launch cmd minimized", ui.launch_command().endswith("--minimized"), True)

# ---------- меню
mm = ui.menu_model(tmp_settings(commas=False), True, False)
ids = [i[0] for i in mm if i[0] != "sep"]
check("menu items", ids, ["toggle", "commas", "spelling", "pause_period", "questions", "autostart", "undo", "show", "quit"])
check("menu checks", {i[0]: i[2] for i in mm if i[2] is not None},
      {"toggle": True, "commas": False, "spelling": True, "pause_period": True, "questions": True, "autostart": False})
check("undo disabled", [i[3] for i in mm if i[0] == "undo"], [False])
check("toggle shows hotkey", "Ctrl+Alt+Space" in mm[0][1], True)

# ---------- склейка с AutoCorrectApp (фейк без tk/pynput)
class Root:
    def after(self, ms, fn):
        fn()

    def protocol(self, *a):
        pass

    def withdraw(self):
        self.hidden = True


class FakeApp:
    def __init__(self, settings):
        self.lock = threading.Lock()
        self._injecting = False
        self.is_active = False
        self.held = set()
        self.root = Root()
        self.core = Flagged(FIXES, NAMES, settings)
        self.screen = ""
        self.closed = False

    def _toggle(self):
        self.is_active = not self.is_active

    def _apply(self, erase, text):
        self.screen = self.screen[: len(self.screen) - erase] + text

    def _on_click(self, *a):
        self.core.break_context()

    def _on_close(self):
        self.closed = True

    def _on_press(self, key):  # мини-копия main.AutoCorrectApp._on_press
        if not self.is_active:
            return
        ch = key.char
        if ch is not None:
            self.screen += ch
            act = self.core.feed_char(ch)
        elif key.name == "space":
            self.screen += " "
            act = self.core.feed_space()
        else:
            self.core.break_context()
            return
        if act:
            self._apply(*act)


st = tmp_settings(autostart=True)
app = FakeApp(st)
reg2 = FakeReg()
ctl = ui.UIController(app, settings=st, autostart=ui.Autostart(registry=reg2), tray=False)
ctl.start()
ctl.hotkey_listener = None  # без pynput
check("starts enabled from settings", app.is_active, True)
check("autostart synced on start", reg2.read(ui.RUN_KEY, "AutoCorrect") is not None, True)


def press(text):
    for ch in text:
        app._on_press(K("space") if ch == " " else K(char=ch))


press("привет  как ")
check("typing through wrapper", app.screen, "Привет. Как ")
app.screen = ""
app.core.reset()
# замена без опоры на правила ядра: двойной пробел → ". "
press("ок  ")
check("pause dot applied", app.screen, "Ок. ")
check("undo available", ctl.undo.can_undo(), True)
ctl.do_undo()
app._injecting = False
import time as _t
_t.sleep(0.05)
check("ctrl+z restored original", app.screen, "Ок  ")
check("undo used up", ctl.undo.can_undo(), False)
press("x")
press(" ")
app._on_press(K("left"))
check("other key kills undo", ctl.undo.can_undo(), False)
check("checked(toggle) = active", ctl.checked("toggle"), True)
check("checked(commas)", ctl.checked("commas"), True)
st.set("commas", False)
app.screen = ""
app.core.reset()
press("я знаю что ты ")
check("live commas OFF via settings", "," in app.screen, False)
ctl.toggle()
check("toggle off", (app.is_active, st["enabled"]), (False, False))
press("abc")
check("off: nothing typed through", app.screen.endswith("abc"), False)
st.set("autostart", False)
check("autostart checkbox removes", reg2.read(ui.RUN_KEY, "AutoCorrect"), None)
ctl._on_close_to_tray()
check("close without tray quits", app.closed, True)

# ---------- совместимость с WinGuard (3)
class Gate:
    def __init__(self):
        self.busy = False
        self.began = 0

    def begin(self):
        self.began += 1
        self.busy = True


class Guard:
    def __init__(self):
        self.gate = Gate()
        self.calls = []

    def is_ours(self, d):
        return getattr(d, "dwExtraInfo", 0) == 1

    def is_replay(self, d):
        return getattr(d, "dwExtraInfo", 0) == 2

    def replace(self, erase, text):
        self.calls.append((erase, text))
        self.gate.busy = False


class Data:
    def __init__(self, vk, extra=0):
        self.vkCode, self.flags, self.dwExtraInfo = vk, 0, extra


class Listener:
    def __init__(self):
        self.suppressed = 0

    def suppress_event(self):
        self.suppressed += 1


st2 = tmp_settings()
app2 = FakeApp(st2)
app2.guard = Guard()
app2.listener = Listener()
orig_calls = []
app2._win_filter = lambda msg, data: orig_calls.append(data.vkCode) or True
ctl2 = ui.UIController(app2, settings=st2, autostart=ui.Autostart(registry=FakeReg()), tray=False)
ctl2.wrap()
app2.held = {CTRL}
ctl2.undo.record("что ", ", что ")
app2.guard.gate.busy = True
app2._win_filter(0x0100, Data(0x5A))
check("guard busy: Ctrl+Z goes to (3) first", (orig_calls, ctl2.undo.can_undo()), ([0x5A], True))
app2.guard.gate.busy = False
app2._win_filter(0x0100, Data(0x5A, extra=1))
check("our injected Z ignored", ctl2.undo.can_undo(), True)
app2._win_filter(0x0100, Data(0x5A))
_t.sleep(0.05)
check("undo via guard.replace", (app2.guard.calls, app2.guard.gate.began, app2.listener.suppressed),
      ([(6, "что ")], 1, 1))

# ---------- известное ограничение: Ctrl+Z во время замены (gate.busy)
st4 = tmp_settings()
app4 = FakeApp(st4)
app4.guard = Guard()
app4.listener = Listener()
passed = []
app4._win_filter = lambda msg, data: passed.append(data.vkCode) or True
ctl4 = ui.UIController(app4, settings=st4, autostart=ui.Autostart(registry=FakeReg()), tray=False)
ctl4.wrap()
app4.held = {CTRL}
ctl4.undo.record("  ", ". ")
app4.guard.gate.busy = True  # замена ещё идёт
undo_calls = []
real_do_undo = ctl4.do_undo
ctl4.do_undo = lambda: undo_calls.append(1) or real_do_undo()
r = app4._win_filter(0x0100, Data(0x5A))
check("Ctrl+Z during replace: goes to (3) queue path", passed, [0x5A])
check("Ctrl+Z during replace: not ours, no suppress", (undo_calls, app4.listener.suppressed), ([], 0))
check("Ctrl+Z during replace: our undo not spent", ctl4.undo.can_undo(), True)
check("Ctrl+Z during replace: no guard.replace", app4.guard.calls, [])
app4.guard.gate.busy = False
app4._win_filter(0x0100, Data(0x5A, extra=2))  # переигранный из очереди Ctrl+Z
check("replayed Ctrl+Z: still not ours (no double undo)", (undo_calls, app4.guard.calls), ([], []))

print("\n%s: %d fail(s)" % ("PASS" if not fails else "FAIL", fails))
sys.exit(1 if fails else 0)
