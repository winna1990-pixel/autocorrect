"""Сборка ru_words.json.gz из частотного списка FrequencyWords (OpenSubtitles 2018).

Источник: https://github.com/hermitdave/FrequencyWords (content/2018/ru/ru_full.txt),
данные под лицензией CC BY-SA 4.0 (© Hermit Dave, OpenSubtitles.org).
Запуск:
    python tools/build_ru_words.py ru_full.txt ru_words.json.gz
Берём все кириллические слова с частотой >= MIN_FREQ, ничего не выкидываем.
"""
import gzip
import json
import re
import sys

MIN_FREQ = 3
rx = re.compile(r"^[а-яё]+(-[а-яё]+)?$")


def main(src, dst):
    freq = {}
    with open(src, encoding="utf-8") as f:
        for line in f:
            w, n = line.rsplit(" ", 1)
            n = int(n)
            if n < MIN_FREQ:
                break  # файл отсортирован по убыванию частоты
            if rx.match(w):
                freq[w] = n
    with gzip.open(dst, "wt", encoding="utf-8", compresslevel=9) as f:
        json.dump(freq, f, ensure_ascii=False, separators=(",", ":"))
    print(f"слов: {len(freq)}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
