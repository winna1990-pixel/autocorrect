"""
ui.py: интерфейс автокорректора (кодер 4, vitaa_games).

Что даёт модуль:
  * Settings: настройки в JSON (%APPDATA%/AutoCorrect/settings.json),
    галочки: запятые, орфография, точка по паузе (двойной пробел), автозапуск,
    хоткей вкл/выкл.
  * FlaggedCorrector(Corrector): то же ядро, но уважает галочки.
  * UndoTracker: отмена последней замены по Ctrl+Z.
  * Autostart: автозапуск через HKCU\\...\\Run (Windows).
  * parse_hotkey / HotkeyMatcher: хоткей вкл/выкл без pynput.GlobalHotKeys.
  * TrayIcon: иконка в трее (pystray + Pillow), меню с галочками.
  * install(app): подключение к AutoCorrectApp одной строкой, main.py не правится
    этим модулем, (5) добавляет вызов сам.

Логика (всё, кроме TrayIcon и install) работает без pynput/pystray/tk:
её проверяет test_ui.py на любом ПК.

Известные ограничения:
  * Ctrl+Z во время замены. Если Ctrl+Z нажат, пока идёт замена (очередь WinGuard
    кодера 3 занята, gate.busy), мы его не перехватываем: он встаёт в очередь (3)
    и после замены переигрывается программе как обычный Ctrl+Z (отмена самой
    программы, не наша). Наша запись Undo при этом не тратится и не срабатывает
    вторым откатом, так что двойной отмены нет. Тест: «Ctrl+Z during replace».
  * Замены с Enter не отменяются: сообщение в мессенджере уже ушло.
  * Отмена живёт UNDO_TIMEOUT секунд и до первой другой клавиши или клика.
"""

import json
import logging
import os
import sys
import threading
import time

logger = logging.getLogger("AutoCorrect.ui")

APP_NAME = "AutoCorrect"
DEFAULT_HOTKEY = "<ctrl>+<alt>+<space>"
UNDO_TIMEOUT = 5.0  # сек: после этого Ctrl+Z снова принадлежит программе

DEFAULTS = {
    "enabled": True,        # включать проверку при старте
    "commas": True,         # запятые перед «что», «но», «который»…
    "spelling": True,       # исправления по dictionary.txt и большому словарю
    "pause_period": True,   # точка после паузы 2 с и по двойному пробелу
    "questions": True,      # v1.0.4: «?» в конце вопроса вместо «.»
    "autostart": False,     # запуск вместе с Windows
    "start_minimized": True,  # при автозапуске сразу в трей
    "hotkey_toggle": DEFAULT_HOTKEY,
}


# ───────────────────────── настройки ─────────────────────────

def settings_dir() -> str:
    base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, APP_NAME)


class Settings:
    def __init__(self, path: str = None):
        self.path = path or os.path.join(settings_dir(), "settings.json")
        self.data = dict(DEFAULTS)
        self._listeners = []

    def load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if isinstance(raw, dict):
                for k, v in raw.items():
                    if k in DEFAULTS and type(v) is type(DEFAULTS[k]):
                        self.data[k] = v
        except FileNotFoundError:
            pass
        except Exception as exc:  # битый файл не должен ронять программу
            logger.warning("settings.json не прочитан (%s), беру по умолчанию", exc)
        if parse_hotkey(self.data["hotkey_toggle"]) is None:
            self.data["hotkey_toggle"] = DEFAULT_HOTKEY
        return self

    def save(self):
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, self.path)
        except Exception as exc:
            logger.error("settings.json не сохранён: %s", exc)

    def __getitem__(self, key):
        return self.data[key]

    def set(self, key, value):
        if key not in DEFAULTS:
            raise KeyError(key)
        if self.data.get(key) == value:
            return
        self.data[key] = value
        self.save()
        for cb in list(self._listeners):
            try:
                cb(key, value)
            except Exception as exc:
                logger.debug("settings listener: %s", exc)

    def toggle(self, key):
        self.set(key, not self.data[key])
        return self.data[key]

    def on_change(self, cb):
        self._listeners.append(cb)


# ───────────────────────── ядро с галочками ─────────────────────────

def make_flagged_corrector(base_cls):
    """Подкласс ядра из main.py, который уважает галочки.

    Не копирует логику Corrector, только выключает куски:
      commas=False    → не ставит запятую (gap_space гасим до _flush)
      spelling=False  → не меняет слова по словарю (имена и заглавные остаются)
      pause_period=False → двойной пробел остаётся двумя пробелами
    """

    if hasattr(base_cls, "apply_settings"):
        # v1.0.3: ядро само умеет галочки (commas/spelling/pause_period)
        class NativeFlagged(base_cls):
            def __init__(self, fixes=None, names=None, settings=None, **kw):
                super().__init__(fixes, names, settings=settings, **kw)
        return NativeFlagged

    class FlaggedCorrector(base_cls):
        def __init__(self, fixes=None, names=None, settings=None):
            self._all_fixes = dict(fixes or {})
            self.settings = settings
            super().__init__(fixes, names)
            self.apply_settings()

        def _flag(self, key):
            return True if self.settings is None else bool(self.settings[key])

        def apply_settings(self):
            self.fixes = dict(self._all_fixes) if self._flag("spelling") else {}

        def _flush(self, trigger, end_mark=""):
            if not self._flag("commas"):
                self.gap_space = False
            return super()._flush(trigger, end_mark)

        def feed_space(self):
            if not self._flag("pause_period") and not self.buffer and self.spaces >= 1:
                self.last_punct = ""
                self.spaces += 1
                self.prev_word = ""
                return None
            return super().feed_space()

    return FlaggedCorrector


# ───────────────────────── отмена Ctrl+Z ─────────────────────────

class UndoTracker:
    """Помнит последнюю замену и умеет её откатить.

    record(original, replacement): original — что набрал человек (то, что мы
    стёрли), replacement — что мы напечатали вместо этого.
    Ctrl+Z работает, пока после замены не было других клавиш и не прошло
    UNDO_TIMEOUT секунд. Иначе Ctrl+Z уходит программе как обычно.
    """

    def __init__(self, timeout=UNDO_TIMEOUT, clock=time.monotonic):
        self.timeout = timeout
        self.clock = clock
        self.clear()

    def clear(self):
        self.original = None
        self.replacement = None
        self.at = 0.0

    def record(self, original: str, replacement: str):
        if original == replacement:
            return
        self.original, self.replacement, self.at = original, replacement, self.clock()

    def touch(self):
        """Любая другая клавиша/клик после замены — отменять уже нечего."""
        self.clear()

    def can_undo(self) -> bool:
        return (
            self.replacement is not None
            and self.clock() - self.at <= self.timeout
        )

    def take(self):
        """→ (сколько стереть, что напечатать) или None. Одноразово."""
        if not self.can_undo():
            self.clear()
            return None
        action = (len(self.replacement), self.original)
        self.clear()
        return action


class TypedTail:
    """Последние напечатанные человеком символы: из них берём original для Undo."""

    def __init__(self, size=64):
        self.size = size
        self.text = ""

    def push(self, ch: str):
        self.text = (self.text + ch)[-self.size:]

    def backspace(self):
        self.text = self.text[:-1]

    def clear(self):
        self.text = ""

    def tail(self, n: int) -> str:
        return self.text[-n:] if n > 0 else ""

    def replace_tail(self, erase: int, text: str):
        """Синхронизировать хвост после нашей замены."""
        if erase > 0:
            self.text = self.text[:-erase] if erase <= len(self.text) else ""
        self.text = (self.text + text)[-self.size:]


# ───────────────────────── хоткей ─────────────────────────

_MOD_ALIASES = {
    "ctrl": "ctrl", "control": "ctrl", "alt": "alt", "shift": "shift",
    "win": "cmd", "cmd": "cmd", "super": "cmd",
}
_NAMED = {"space", "enter", "tab", "esc", "pause", "insert", "home", "end",
          "scroll_lock"} | {"f%d" % i for i in range(1, 25)}


def parse_hotkey(text: str):
    """'<ctrl>+<alt>+<space>' → (frozenset({'ctrl','alt'}), 'space') или None.

    Нужен хотя бы один модификатор (иначе хоткей будет мешать печатать)
    и ровно одна основная клавиша.
    """
    if not isinstance(text, str) or not text.strip():
        return None
    mods, key = set(), None
    for part in text.lower().replace(" ", "").split("+"):
        name = part[1:-1] if part.startswith("<") and part.endswith(">") else part
        if not name:
            return None
        if name in _MOD_ALIASES:
            mods.add(_MOD_ALIASES[name])
        elif key is None and (name in _NAMED or (len(name) == 1 and name.isprintable())):
            key = name
        else:
            return None
    if not mods or key is None:
        return None
    return frozenset(mods), key


def format_hotkey(text: str) -> str:
    """Для меню: '<ctrl>+<alt>+<space>' → 'Ctrl+Alt+Space'."""
    p = parse_hotkey(text)
    if not p:
        return text
    order = ["ctrl", "alt", "shift", "cmd"]
    names = {"ctrl": "Ctrl", "alt": "Alt", "shift": "Shift", "cmd": "Win"}
    mods = [names[m] for m in order if m in p[0]]
    key = p[1].upper() if len(p[1]) == 1 or p[1].startswith("f") else p[1].capitalize()
    return "+".join(mods + [key])


class HotkeyMatcher:
    """Сравнивает нажатие с хоткеем. Получает уже нормализованные имена:
    held_mods — {'ctrl','alt','shift','cmd'}, key — 'space' / 'a' / 'f12'."""

    def __init__(self, text: str = DEFAULT_HOTKEY):
        self.set(text)

    def set(self, text: str):
        self.spec = parse_hotkey(text) or parse_hotkey(DEFAULT_HOTKEY)

    def matches(self, held_mods, key: str) -> bool:
        if not key:
            return False
        return frozenset(held_mods) == self.spec[0] and key.lower() == self.spec[1]


def normalize_pynput(key, held):
    """pynput Key/KeyCode + набор зажатых → (mods, key_name). Без импорта pynput."""
    mods = set()
    for k in held:
        n = getattr(k, "name", "") or ""
        for m in ("ctrl", "alt", "shift", "cmd"):
            if n.startswith(m):
                mods.add(m)
    name = getattr(key, "name", None)
    if name is None:
        vk = getattr(key, "vk", None)
        ch = getattr(key, "char", None)
        if vk is not None and (0x41 <= vk <= 0x5A or 0x30 <= vk <= 0x39):
            name = chr(vk).lower()  # с Ctrl char бывает '\x01', берём vk
        elif ch and ch.isprintable():
            name = ch.lower()
    return mods, (name or "")


class HotkeyListener:
    """Отдельный слушатель только для хоткея: работает, даже когда проверка выключена
    (основной listener в main.py живёт только во включённом режиме)."""

    def __init__(self, matcher, on_hotkey):
        self.matcher = matcher
        self.on_hotkey = on_hotkey
        self.held = set()
        self.listener = None

    def handle_press(self, key):
        n = getattr(key, "name", "") or ""
        if n.startswith(("ctrl", "alt", "shift", "cmd")):
            self.held.add(key)
            return False
        mods, name = normalize_pynput(key, self.held)
        if self.matcher.matches(mods, name):
            self.on_hotkey()
            return True
        return False

    def handle_release(self, key):
        self.held.discard(key)

    def start(self):
        try:
            from pynput import keyboard
        except ImportError:
            logger.warning("pynput не найден — хоткей выключен")
            return False
        self.listener = keyboard.Listener(on_press=self.handle_press,
                                          on_release=self.handle_release)
        self.listener.daemon = True
        self.listener.start()
        return True

    def stop(self):
        if self.listener:
            try:
                self.listener.stop()
            except Exception:
                pass
            self.listener = None


# ───────────────────────── автозапуск ─────────────────────────

RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"


def launch_command(minimized=True) -> str:
    if getattr(sys, "frozen", False):
        cmd = '"%s"' % os.path.abspath(sys.executable)
    else:
        exe = sys.executable
        pyw = os.path.join(os.path.dirname(exe), "pythonw.exe")
        if os.path.exists(pyw):
            exe = pyw
        main_py = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0] or __file__)), "main.py")
        cmd = '"%s" "%s"' % (exe, main_py)
    return cmd + (" --minimized" if minimized else "")


class Autostart:
    """HKCU\\...\\Run\\AutoCorrect. registry можно подменить (тесты, не Windows)."""

    def __init__(self, registry=None, name=APP_NAME):
        self.name = name
        self.reg = registry if registry is not None else _WinRegistry.get()

    @property
    def supported(self) -> bool:
        return self.reg is not None

    def is_enabled(self) -> bool:
        return bool(self.reg and self.reg.read(RUN_KEY, self.name))

    def enable(self, command: str = None) -> bool:
        if not self.reg:
            return False
        try:
            self.reg.write(RUN_KEY, self.name, command or launch_command())
            return True
        except Exception as exc:
            logger.error("Автозапуск не включён: %s", exc)
            return False

    def disable(self) -> bool:
        if not self.reg:
            return False
        try:
            self.reg.delete(RUN_KEY, self.name)
            return True
        except Exception as exc:
            logger.error("Автозапуск не выключен: %s", exc)
            return False

    def sync(self, want: bool, command: str = None) -> bool:
        """Привести реестр к галочке; если путь к exe сменился — переписать."""
        if not self.reg:
            return False
        if want:
            cmd = command or launch_command()
            if self.reg.read(RUN_KEY, self.name) != cmd:
                return self.enable(cmd)
            return True
        return self.disable() if self.is_enabled() else True


class _WinRegistry:
    @staticmethod
    def get():
        if sys.platform != "win32":
            return None
        try:
            import winreg  # noqa: F401
            return _WinRegistry()
        except ImportError:
            return None

    def read(self, path, name):
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, path) as k:
                return winreg.QueryValueEx(k, name)[0]
        except FileNotFoundError:
            return None

    def write(self, path, name, value):
        import winreg
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, path) as k:
            winreg.SetValueEx(k, name, 0, winreg.REG_SZ, value)

    def delete(self, path, name):
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_SET_VALUE) as k:
                winreg.DeleteValue(k, name)
        except FileNotFoundError:
            pass


# ───────────────────────── меню трея (модель) ─────────────────────────

MENU_TOGGLES = [
    ("commas", "Запятые"),
    ("spelling", "Орфография"),
    ("pause_period", "Точка после паузы (2 с) и двойного пробела"),
    ("questions", "Знак вопроса в конце вопроса"),
    ("autostart", "Запускать вместе с Windows"),
]


def menu_model(settings, is_active: bool, can_undo: bool):
    """Список пунктов меню как данные: тестируется без pystray.

    Каждый пункт: (id, текст, checked|None, enabled).
    """
    hk = format_hotkey(settings["hotkey_toggle"])
    items = [
        ("toggle", "Включено (%s)" % hk, is_active, True),
        ("sep", "", None, True),
    ]
    for key, label in MENU_TOGGLES:
        items.append((key, label, bool(settings[key]), True))
    items += [
        ("sep", "", None, True),
        ("undo", "Отменить последнюю замену (Ctrl+Z)", None, can_undo),
        ("show", "Открыть окно", None, True),
        ("quit", "Выход", None, True),
    ]
    return items


ICON_FILE = os.path.join("assets", "icon_64.png")


def resource_path(rel: str) -> str:
    """Файл рядом с exe, потом внутри onefile-exe (sys._MEIPASS), потом рядом с ui.py."""
    dirs = []
    if getattr(sys, "frozen", False):
        dirs.append(os.path.dirname(os.path.abspath(sys.executable)))
    if getattr(sys, "_MEIPASS", None):
        dirs.append(sys._MEIPASS)
    dirs.append(os.path.dirname(os.path.abspath(__file__)))
    for d in dirs:
        p = os.path.join(d, rel)
        if os.path.exists(p):
            return p
    return ""


def load_icon_image(active: bool, size=64, path=None):
    """Утверждённая иконка assets/icon_64.png; выключено — серая.
    Нет файла или Pillow не справился — рисуем запасную; нет и Pillow — None (без трея)."""
    p = resource_path(ICON_FILE) if path is None else path
    if p:
        try:
            from PIL import Image
            img = Image.open(p).convert("RGBA")
            if img.size != (size, size):
                img = img.resize((size, size))
            if not active:
                alpha = img.getchannel("A")
                img = img.convert("L").convert("RGBA")
                img.putalpha(alpha)
            return img
        except Exception as exc:
            logger.warning("иконка %s не загружена (%s) — запасная", p, exc)
    try:
        return make_icon_image(active, size)
    except Exception as exc:
        logger.warning("запасная иконка не нарисована: %s", exc)
        return None


def make_icon_image(active: bool, size=64):
    """Иконка рисуется кодом: зелёный круг (вкл) / серый (выкл) с буквой «А»."""
    from PIL import Image, ImageDraw, ImageFont
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    color = (46, 160, 67, 255) if active else (130, 130, 130, 255)
    d.ellipse((2, 2, size - 3, size - 3), fill=color)
    font = None
    for name in ("segoeuib.ttf", "arialbd.ttf", "DejaVuSans-Bold.ttf"):
        try:
            font = ImageFont.truetype(name, int(size * 0.6))
            break
        except Exception:
            continue
    if font is None:
        font = ImageFont.load_default()
    text = "А"
    box = d.textbbox((0, 0), text, font=font)
    w, h = box[2] - box[0], box[3] - box[1]
    d.text(((size - w) / 2 - box[0], (size - h) / 2 - box[1]), text, fill="white", font=font)
    return img


class TrayIcon:
    """Обёртка над pystray. Все колбэки уходят в tk через app.root.after."""

    def __init__(self, ctl):
        self.ctl = ctl
        self.icon = None

    def start(self):
        try:
            import pystray
        except ImportError:
            logger.warning("pystray не установлен — трей выключен")
            return False
        self._pystray = pystray
        image = load_icon_image(self.ctl.is_active())
        if image is None:
            logger.warning("нет иконки (Pillow?) — трей выключен")
            return False
        try:
            self.icon = pystray.Icon(APP_NAME, image, "Автокорректор", self._menu())
            self.icon.run_detached()
        except Exception as exc:
            logger.error("трей не запущен: %s", exc)
            self.icon = None
            return False
        return True

    def _menu(self):
        pystray = self._pystray
        items = []
        for item_id, text, checked, enabled in menu_model(
            self.ctl.settings, self.ctl.is_active(), self.ctl.undo.can_undo()
        ):
            if item_id == "sep":
                items.append(pystray.Menu.SEPARATOR)
                continue
            action = (lambda i: (lambda icon, it: self.ctl.dispatch(i)))(item_id)
            if checked is None:
                items.append(pystray.MenuItem(
                    text, action, enabled=enabled, default=(item_id == "show")))
            else:
                key = item_id
                items.append(pystray.MenuItem(
                    text, action,
                    checked=(lambda k: (lambda it: self.ctl.checked(k)))(key)))
        return pystray.Menu(*items)

    def refresh(self):
        if not self.icon:
            return
        try:
            image = load_icon_image(self.ctl.is_active())
            if image is not None:
                self.icon.icon = image
            self.icon.title = "Автокорректор: " + ("включён" if self.ctl.is_active() else "выключен")
            self.icon.menu = self._menu()
            self.icon.update_menu()
        except Exception as exc:
            logger.debug("tray refresh: %s", exc)

    def stop(self):
        if self.icon:
            try:
                self.icon.stop()
            except Exception:
                pass
            self.icon = None


# ───────────────────────── подключение к AutoCorrectApp ─────────────────────────

class UIController:
    """Склейка: настройки + трей + хоткей + Undo вокруг готового AutoCorrectApp.

    Не меняет main.py: оборачивает методы экземпляра app (_on_press, _apply,
    _toggle, _on_click, _win_filter, _on_close).
    """

    VK_Z = 0x5A

    def __init__(self, app, settings=None, autostart=None, tray=True):
        self.app = app
        self.settings = settings or Settings().load()
        self.autostart = autostart or Autostart()
        self.undo = UndoTracker()
        self.tail = TypedTail()
        self.hotkey = HotkeyMatcher(self.settings["hotkey_toggle"])
        self.tray = TrayIcon(self) if tray else None
        self.hotkey_listener = None
        self.settings.on_change(self._on_setting)

    # --- состояние для меню
    def is_active(self):
        return bool(getattr(self.app, "is_active", False))

    def checked(self, key):
        if key == "toggle":
            return self.is_active()
        return bool(self.settings[key])

    # --- команды из меню/хоткея (могут прийти из чужого потока)
    def dispatch(self, item_id):
        root = getattr(self.app, "root", None)
        fn = {
            "toggle": self.toggle,
            "undo": self.do_undo,
            "show": self.show_window,
            "quit": self.quit,
        }.get(item_id)
        if fn is None and item_id in DEFAULTS:
            fn = (lambda: self.settings.toggle(item_id))
        if fn is None:
            return
        if root is not None:
            root.after(0, fn)
        else:
            fn()

    def toggle(self):
        self.app._toggle()
        self.undo.clear()
        self.tail.clear()
        self.settings.set("enabled", self.is_active())
        self._refresh()

    def show_window(self):
        root = self.app.root
        root.deiconify()
        root.lift()
        root.focus_force()

    def quit(self):
        if self.hotkey_listener:
            self.hotkey_listener.stop()
        if self.tray:
            self.tray.stop()
        self._orig_close()

    def do_undo(self):
        action = self.undo.take()
        if action:
            erase, text = action
            with self.app.lock:
                self.app.core.break_context()
            guard = getattr(self.app, "guard", None)
            if guard is not None:
                guard.gate.begin()  # клавиши во время отката уйдут в очередь (3)
                target = guard.replace
            else:
                target = self._orig_apply
            threading.Thread(target=target, args=(erase, text), daemon=True).start()
            self.tail.clear()
        self._refresh()
        return bool(action)

    def _on_setting(self, key, value):
        core = self.app.core
        if hasattr(core, "apply_settings"):
            core.apply_settings()
        if key == "autostart":
            if not self.autostart.sync(value) and value:
                logger.warning("Автозапуск недоступен на этой системе")
        if key == "hotkey_toggle":
            self.hotkey.set(value)
            if self.hotkey_listener:
                self.hotkey_listener.matcher = self.hotkey
        self._refresh()

    def _refresh(self):
        if self.tray:
            root = getattr(self.app, "root", None)
            if root is not None:
                root.after(0, self.tray.refresh)
            else:
                self.tray.refresh()

    # --- обёртки методов app
    def wrap(self):
        app = self.app
        self._orig_press = app._on_press
        self._orig_apply = app._apply
        self._orig_click = app._on_click
        self._orig_close = app._on_close
        self._orig_filter = getattr(app, "_win_filter", None)
        app._on_press = self._on_press
        app._apply = self._apply
        app._on_click = self._on_click
        app._on_close = self._on_close_to_tray
        if getattr(app, "root", None) is not None:
            app.root.protocol("WM_DELETE_WINDOW", self._on_close_to_tray)
        if self._orig_filter is not None:
            app._win_filter = self._win_filter

    def _on_press(self, key):
        app = self.app
        if app._injecting:
            return
        mods, name = normalize_pynput(key, app.held)
        if self.hotkey.matches(mods, name):
            return  # хоткей обрабатывает HotkeyListener (он работает и когда выключено)
        if mods == {"ctrl"} and name == "z" and sys.platform != "win32":
            # на Windows Ctrl+Z ловит _win_filter (там можно подавить событие)
            if self.undo.can_undo():
                self.dispatch("undo")
                return
        ch = getattr(key, "char", None)
        if not mods and ch is not None and ch.isprintable():
            self.tail.push(ch)
        elif getattr(key, "name", None) == "space" and not mods:
            self.tail.push(" ")
        elif getattr(key, "name", None) == "backspace":
            self.tail.backspace()
        elif getattr(key, "name", "") and not getattr(key, "name", "").startswith(("shift", "caps")):
            if getattr(key, "name", "") not in ("ctrl", "ctrl_l", "ctrl_r", "alt", "alt_l",
                                                 "alt_r", "alt_gr", "cmd", "cmd_l", "cmd_r"):
                self.tail.clear()
        if getattr(key, "name", "") not in ("ctrl", "ctrl_l", "ctrl_r", "shift", "shift_l",
                                            "shift_r", "caps_lock"):
            self.undo.touch()
        if app.is_active:
            self._orig_press(key)

    def _apply(self, erase, text):
        # v1.0.3: что набрал человек, знает само ядро (app._undo_original);
        # False — эту замену не отменяем (Enter, откат по Backspace).
        original = getattr(self.app, "_undo_original", None)
        self.app._undo_original = None
        typed = self.tail.tail(erase) if original is None else original
        self.tail.replace_tail(erase, text)
        self._orig_apply(erase, text)
        # Замены с Enter не отменяем: сообщение в мессенджере уже ушло.
        if original is False or "\n" in text:
            self.undo.clear()  # Enter/Backspace-отмена глушатся в хуке — touch() их не видит
            self._refresh()
            return
        if original is not None or len(typed) == erase:
            self.undo.record(typed, text)
            self._refresh()

    def _on_click(self, *a):
        self.undo.touch()
        self.tail.clear()
        self._orig_click(*a)

    def _win_filter(self, msg, data):
        WM_KEYDOWN, WM_SYSKEYDOWN, LLKHF_INJECTED = 0x0100, 0x0104, 0x10
        app = self.app
        guard = getattr(app, "guard", None)  # WinGuard от (3), если (5) его подключил
        if guard is not None and (
            guard.is_ours(data) or guard.is_replay(data) or guard.gate.busy
        ):
            # наши/переигранные события и очередь (3) — сначала им, Ctrl+Z не трогаем
            return self._orig_filter(msg, data)
        if (
            not app._injecting and not (data.flags & LLKHF_INJECTED)
            and msg in (WM_KEYDOWN, WM_SYSKEYDOWN) and data.vkCode == self.VK_Z
        ):
            mods, _ = normalize_pynput(None, app.held)
            if mods == {"ctrl"} and self.undo.can_undo():
                # прямо в хуке: gate.begin() до того, как следующие клавиши дойдут до окна
                self.do_undo()
                app.listener.suppress_event()
                return False
        return self._orig_filter(msg, data)

    def _on_close_to_tray(self):
        if self.tray and self.tray.icon:
            self.app.root.withdraw()  # крестик прячет в трей, выход — из меню
        else:
            self.quit()

    # --- старт
    def start(self, minimized=False):
        self.wrap()
        self.autostart.sync(self.settings["autostart"])
        tray_ok = self.tray.start() if self.tray else False
        self.hotkey_listener = HotkeyListener(self.hotkey, lambda: self.dispatch("toggle"))
        self.hotkey_listener.start()
        if self.settings["enabled"] and not self.is_active():
            self.app._toggle()
        if minimized and tray_ok:
            self.app.root.withdraw()
        self._refresh()
        return self


def install(app, minimized=None, tray=True, settings=None):
    """Подключить интерфейс к созданному AutoCorrectApp. Вызывать до app.run().

    app.core должен быть FlaggedCorrector (см. make_flagged_corrector) — иначе
    галочки сохраняются, но ядро их не слышит.
    """
    if minimized is None:
        minimized = "--minimized" in sys.argv
    settings = settings or Settings().load()
    core = getattr(app, "core", None)
    if core is not None and not hasattr(core, "apply_settings"):
        Flagged = make_flagged_corrector(type(core))
        app.core = Flagged(core.fixes, core.names, settings=settings)
    elif core is not None:
        if getattr(core, "settings", None) is not settings:
            core.settings = settings
        core.apply_settings()
    ctl = UIController(app, settings=settings, tray=tray)
    return ctl.start(minimized=minimized)
