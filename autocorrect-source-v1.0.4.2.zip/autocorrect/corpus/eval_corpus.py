"""Процент попаданий по corpus.tsv (кодер 1). Без GUI, работает на Linux.

python eval_corpus.py                 # сводка по разделам
python eval_corpus.py -v              # + промахи
python eval_corpus.py --cat comma_intro
python eval_corpus.py --min 80        # exit 1 ниже порога (для CI)
python eval_corpus.py --src ../../fixed

Берёт fix_text(text) из main.py. Если её ещё нет, печатает фразу
посимвольно через Corrector и жмёт Enter в конце (режим --typing).
"""
import argparse, logging, os, sys
from collections import OrderedDict

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_SRC = os.path.normpath(os.path.join(HERE, ".."))  # папка с main.py


def read_corpus(path):
    rows, cat = [], "all"
    with open(path, encoding="utf-8") as f:
        for n, line in enumerate(f, 1):
            line = line.rstrip("\n")
            if not line:
                continue
            if line == "#" or line.startswith("# "):  # «#scrapdive» — это фраза
                t = line[1:].strip()
                if t.startswith("[") and t.endswith("]"):
                    cat = t[1:-1]
                continue
            parts = line.split("\t")
            if len(parts) != 2:
                raise SystemExit(f"corpus.tsv:{n}: нужно 2 колонки через TAB")
            rows.append((cat, parts[0], parts[1]))
    return rows


def make_fixer(src, force_typing=False):
    sys.path.insert(0, src)
    logging.disable(logging.CRITICAL)
    import main  # noqa
    if hasattr(main, "fix_text") and not force_typing:
        return main.fix_text, "fix_text"
    if hasattr(main, "default_corrector") and hasattr(main, "type_through"):
        # v1.0.3: тот же Corrector, что в программе (правила, орфография, запятые кодера 2)
        def typed_full(s):
            return main.type_through(main.default_corrector(), s + "\n")
        return typed_full, "typing"
    fixes, names = main.load_dictionary(os.path.join(src, "dictionary.txt"))

    def typed(s):
        c = main.Corrector(fixes, names)
        out = ""
        for ch in s + "\n":
            out += ch
            a = c.feed_enter() if ch == "\n" else c.feed_space() if ch == " " else c.feed_char(ch)
            if a:
                erase, text = a
                out = out[: len(out) - erase] + text
        return out
    return typed, "typing"


def main_():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default=DEFAULT_SRC)
    ap.add_argument("--corpus", default=os.path.join(HERE, "corpus.tsv"))
    ap.add_argument("-v", "--verbose", action="store_true")
    ap.add_argument("--cat")
    ap.add_argument("--min", type=float)
    ap.add_argument("--future", default="question_yn",
                    help="разделы следующей версии через запятую: показываем отдельно, в планку не входят")
    ap.add_argument("--typing", action="store_true", help="мерить посимвольный набор")
    a = ap.parse_args()

    fix, mode = make_fixer(os.path.abspath(a.src), a.typing)
    rows = read_corpus(a.corpus)
    if a.cat:
        rows = [r for r in rows if r[0] == a.cat]
    stat, misses = OrderedDict(), []
    for cat, src, want in rows:
        got = fix(src).rstrip("\n").rstrip(" ")
        ok, n = stat.get(cat, (0, 0))
        stat[cat] = (ok + (got == want), n + 1)
        if got != want:
            misses.append((cat, src, got, want))

    print(f"режим: {mode}")
    print(f"{'раздел':<15}{'попал':>7}{'всего':>7}{'%':>8}")
    for cat, (ok, n) in stat.items():
        print(f"{cat:<15}{ok:>7}{n:>7}{100*ok/n:>7.1f}%")
    tok = sum(v[0] for v in stat.values()); tn = sum(v[1] for v in stat.values())
    pct = 100 * tok / tn if tn else 0.0
    print(f"{'ИТОГО':<15}{tok:>7}{tn:>7}{pct:>7.1f}%")
    future = {c for c in (a.future or "").split(",") if c}
    if future & set(stat):
        bok = sum(v[0] for c, v in stat.items() if c not in future)
        bn = sum(v[1] for c, v in stat.items() if c not in future)
        pct = 100 * bok / bn if bn else 0.0
        print(f"{'ПЛАНКА':<15}{bok:>7}{bn:>7}{pct:>7.1f}%  (без {', '.join(sorted(future & set(stat)))}: задача v1.0.5)")
    if a.verbose:
        print("\nПромахи:")
        for cat, src, got, want in misses:
            print(f"[{cat}] {src!r}\n   получил {got!r}\n   ожидал  {want!r}")
    if a.min is not None and pct < a.min:
        raise SystemExit(1)


if __name__ == "__main__":
    main_()
