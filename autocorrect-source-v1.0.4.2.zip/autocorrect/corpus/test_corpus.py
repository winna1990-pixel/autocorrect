"""Тесты самого корпуса и оценщика: python test_corpus.py"""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import eval_corpus as ev
here = os.path.dirname(os.path.abspath(__file__))
rows = ev.read_corpus(os.path.join(here, "corpus.tsv"))
cats = {c for c, _, _ in rows}
import build_corpus  # только список C, файл не пишет
rows = ev.read_corpus(os.path.join(here, "corpus.tsv"))
_LINK = re.compile(r"(?:https?://|www\.)\S+$|\S+@\S+\.\w+$")


def ends_with_link(w):
    return bool(_LINK.search(w))


checks = [
    ("corpus.tsv совпадает с build_corpus.C", [(c, a, b) for c, a, b in rows] == [tuple(x) for x in build_corpus.C]),
    ("фраза с # не потерялась", any(s.startswith("#") for _, s, _ in rows)),
    ("вопросы да/нет: 30 фраз", sum(c == "question_yn" for c, _, _ in rows) == 30),
    ("фраза с # не потерялась", any(s.startswith("#") for _, s, _ in rows)),
    ("200+ фраз", len(rows) >= 200),
    ("12 разделов", len(cats) == 12),
    ("нет дублей ввода", len({s for _, s, _ in rows}) == len(rows)),
    ("ожидание с заглавной/не пустое", all(w for _, _, w in rows)),
    ("ожидание кончается знаком (или смайликом)",
     all(w[-1] in ".!?" or w.rsplit(" ", 1)[-1] in (":)", ":(", ";)", ":D")
         or ends_with_link(w) for _, _, w in rows)),  # v1.0.4.2: после ссылки/почты знак не ставим
    ("нет TAB внутри", all("\t" not in s + w for _, s, w in rows)),
]
fix, mode = ev.make_fixer(ev.DEFAULT_SRC, force_typing=True)
checks.append(("оценщик: эталон проходит", fix("привет").rstrip("\n") == "Привет."))
ok = True
for name, res in checks:
    print("OK  " if res else "FAIL", name); ok &= res
raise SystemExit(0 if ok else 1)
