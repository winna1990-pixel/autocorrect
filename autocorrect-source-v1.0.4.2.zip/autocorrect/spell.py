"""Офлайн-проверка орфографии (русский).

Движок: pyspellchecker (MIT). Частотный словарь: ru_words.json.gz
(FrequencyWords / OpenSubtitles 2018, CC BY-SA 4.0), ~465 тыс. словоформ (частота >= 3).
Если pyspellchecker не установлен, работает встроенная копия того же алгоритма.

Правило: исправляем только «уверенные» опечатки.
  * слово целиком кириллица, длина >= 4, не в словаре как частое слово;
  * кандидат на расстоянии 1 (для слов от 7 букв — до 2),
    заметно чаще набранного и без близкого соперника.
"""
import gzip
import json
import logging
import re

logger = logging.getLogger("AutoCorrect")

ALPHA = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"
CYR_WORD = re.compile(r"^[а-яё]+$")

MIN_LEN = 4          # слова до 3 букв не трогаем
STRONG = 25          # слово с такой частотой считаем правильным, не исправляем
MIN_CAND = 500       # кандидат должен быть хотя бы такой частоты
RATIO = 2000         # ... и во столько раз чаще набранного слова (если оно вообще встречается)
UNIQUE = 5           # лучший кандидат во столько раз чаще второго
D2_MIN_LEN = 7       # расстояние 2 — только для длинных слов (7–11 букв)
D2_MAX_LEN = 11      # длиннее — слишком дорого (>20 мс), только расстояние 1
D2_MIN_CAND = 5000
D2_UNIQUE = 10


def _edits1(w):
    splits = [(w[:i], w[i:]) for i in range(len(w) + 1)]
    out = set()
    for a, b in splits:
        if b:
            out.add(a + b[1:])
            for c in ALPHA:
                out.add(a + c + b[1:])
        if len(b) > 1:
            out.add(a + b[1] + b[0] + b[2:])
        for c in ALPHA:
            out.add(a + c + b)
    out.discard(w)
    return out


def _cheap_edits(w):
    """Удаления и перестановки — дёшево, для второго шага расстояния 2."""
    out = set()
    for i in range(len(w)):
        out.add(w[:i] + w[i + 1:])
        if i + 1 < len(w):
            out.add(w[:i] + w[i + 1] + w[i] + w[i + 2:])
    out.discard(w)
    return out


def _ending_only(a, b):
    """Слова отличаются только последними двумя буквами (другая форма слова)."""
    p = 0
    while p < min(len(a), len(b)) and a[p] == b[p]:
        p += 1
    return (len(a) >= 5 and p >= len(a) - 2 and p >= len(b) - 2
            and a[p:] in ENDINGS and b[p:] in ENDINGS)


ENDINGS = (
    "", "а", "я", "о", "е", "и", "ы", "у", "ю", "ь", "й", "ой", "ей", "ом", "ем", "ам", "ям",
    "ах", "ях", "ами", "ями", "ов", "ев", "ий", "ый", "ая", "ое", "ые", "ие", "ого", "его",
    "ому", "ему", "ую", "юю", "ть", "ла", "ли", "ло", "л", "ет", "ит", "ют", "ят", "ут", "ат",
    "ешь", "ишь", "ал", "ил", "ние", "ния", "нию",
)


def _looks_inflected(word, freq, cand):
    """Похоже на другую форму известного слова («заборам» — от «забор»)."""
    for k in (1, 2, 3):
        stem = word[:-k]
        if len(stem) < 5:
            break
        if word[-k:] not in ENDINGS:
            continue  # отрезаем только настоящее окончание
        for e in ENDINGS:
            w = stem + e
            f = freq.get(w, 0)
            # форма считается, только если она не в сотни раз реже кандидата
            if w != word and w != cand and f >= STRONG and f * 100 >= freq.get(cand, 0):
                return True
    return False


class SpellEngine:
    def __init__(self, freq: dict, use_pyspell=True):
        self.freq = freq
        self._edits1 = _edits1
        self.backend = "builtin"
        if use_pyspell:
            try:
                from spellchecker import SpellChecker

                sp = SpellChecker(language=None, distance=1)
                sp.word_frequency.load_json(freq)
                self.freq = sp.word_frequency.dictionary
                self._edits1 = sp.edit_distance_1
                self.backend = "pyspellchecker"
            except Exception as exc:  # нет пакета — встроенный алгоритм
                logger.info("pyspellchecker недоступен (%s), встроенный поиск", exc)

    @classmethod
    def from_file(cls, path: str, use_pyspell=True):
        with gzip.open(path, "rt", encoding="utf-8") as f:
            freq = json.load(f)
        return cls(freq, use_pyspell)

    def __len__(self):
        return len(self.freq)

    def known(self, word: str) -> bool:
        return self.freq.get(word, 0) >= STRONG

    def _best(self, cands, typed_freq, min_cand, unique):
        scored = sorted(
            ((self.freq.get(c, 0), c) for c in cands if self.freq.get(c, 0) >= min_cand),
            reverse=True,
        )
        if not scored:
            return None
        best_f, best = scored[0]
        if typed_freq and best_f < RATIO * typed_freq:
            return None
        if len(scored) > 1:
            second_f, second = scored[1]
            # «ещё»/«еще» — один и тот же кандидат, не соперники
            if second.replace("ё", "е") != best.replace("ё", "е") and best_f < unique * second_f:
                return None
        return best

    def correct(self, word: str):
        """Вернуть исправление для слова в нижнем регистре или None."""
        if len(word) < MIN_LEN or not CYR_WORD.match(word):
            return None
        typed = self.freq.get(word, 0)
        if typed >= STRONG:
            return None
        if typed and len(word) <= 5:
            return None  # короткое слово, которое уже встречалось, — не трогаем
        e1 = self._edits1(word)
        best = self._best(e1, typed, MIN_CAND, UNIQUE)
        if best is None and typed == 0 and D2_MIN_LEN <= len(word) <= D2_MAX_LEN:
            if not any(self.freq.get(c, 0) >= MIN_CAND for c in e1):
                e2 = set()
                pre = word[:2]
                for e in e1:
                    if e[:2] == pre:  # начало слова всё равно должно совпасть
                        e2 |= _cheap_edits(e)
                for e in _cheap_edits(word):
                    if e[:2] == pre:
                        e2 |= self._edits1(e)
                e2.discard(word)
                # только похожие по началу и длине: «малако» -> «молоко» нельзя, «калькой» -> «какой» тоже
                e2 = {c for c in e2 if c[:2] == word[:2] and abs(len(c) - len(word)) <= 1}
                best = self._best(e2, typed, D2_MIN_CAND, D2_UNIQUE)
        if best is None:
            return None
        if _looks_inflected(word, self.freq, best):
            return None  # редкая форма знакомого слова — скорее всего, написано верно
        if typed and _ending_only(word, best):
            # «таблицах»/«таблица»: редкая, но живая форма слова — не трогаем
            return None
        # Не навязываем «ё»: если пользователь пишет через «е» и такое слово есть — берём его
        if "ё" in best and "ё" not in word:
            plain = best.replace("ё", "е")
            if self.freq.get(plain, 0) >= MIN_CAND:
                best = plain
        if best.replace("ё", "е") == word.replace("ё", "е"):
            return None  # разница только в ё — не исправление
        return best
