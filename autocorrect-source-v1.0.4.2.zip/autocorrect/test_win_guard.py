"""Тест win_guard без Windows: python test_win_guard.py"""
import os
import sys

here = os.path.dirname(os.path.abspath(__file__))
for p in (here, os.path.join(here, "..", "fixed"), os.path.join(here, "..", "..", "fixed")):
    sys.path.insert(0, os.path.abspath(p))

import win_guard as wg
from main import Corrector, load_dictionary

import main as _main
_cands = [os.path.join(here, "dictionary.txt"),
          os.path.join(os.path.dirname(os.path.abspath(_main.__file__)), "dictionary.txt"),
          os.path.join(here, "..", "fixed", "dictionary.txt"),
          os.path.join(here, "..", "..", "fixed", "dictionary.txt")]
dict_path = next((p for p in _cands if os.path.exists(p)), "")
fixes, names = load_dictionary(dict_path)
fails = 0


def check(name, got, want):
    global fails
    ok = got == want
    fails += not ok
    print(("PASS" if ok else "FAIL"), name, "" if ok else f"\n  got:  {got!r}\n  want: {want!r}")


def feed(c, ch):
    if ch == "\n":
        return c.feed_enter()
    if ch == " ":
        return c.feed_space()
    return c.feed_char(ch)


def slow(s):
    """Эталон: человек печатает медленно, замена успевает между клавишами."""
    c, out = Corrector(fixes, names), ""
    for ch in s:
        out += ch
        a = feed(c, ch)
        if a:
            out = out[: len(out) - a[0]] + a[1]
    return out


def fast_naive(s, lag):
    """Как v1.0.2: замена приходит через `lag` клавиш, свои клавиши за это время
    уже в окне (их сотрёт Backspace), а Corrector их не видит (_injecting)."""
    c, out, pending, skip = Corrector(fixes, names), "", [], 0
    for ch in s:
        out += ch
        if skip:
            skip -= 1
        else:
            a = feed(c, ch)
            if a:
                pending.append([lag, a])
                skip = lag
        for p in pending:
            p[0] -= 1
        while pending and pending[0][0] < 0:
            _, (e, t) = pending.pop(0)
            out = out[: len(out) - e] + t
    for _, (e, t) in pending:
        out = out[: len(out) - e] + t
    return out


def fast_gated(s, lag):
    """С KeyGate: клавиши во время замены — в очередь, после — переигрываются
    и проходят через Corrector. clock стоит, предохранитель не срабатывает."""
    gate = wg.KeyGate(clock=lambda: 0.0)
    c, out, inflight = Corrector(fixes, names), "", None
    keys = list(s)
    i = 0
    while i < len(keys) or inflight:
        if inflight and (inflight[0] <= 0 or i >= len(keys)):
            e, t = inflight[1]
            out = out[: len(out) - e] + t      # атомарный SendInput
            inflight = None
            q = gate.end()
            keys[i:i] = [ev["ch"] for ev in q]  # replay в том же порядке
            continue
        ch = keys[i]
        i += 1
        if gate.offer({"ch": ch, "vk": 0}):
            inflight[0] -= 1
            continue
        out += ch
        a = feed(c, ch)
        if a:
            gate.begin()
            inflight = [lag, a]
    return out


texts = [
    "приет как дела ",
    "я знаю что ты придешь но позже\n",
    "щас буду  ок короче седня не смогу\n",
    "спс,пака. витя пишет что щас приедет\n",
    "hello world. this is fast typing test ",
]
for t in texts:
    want = slow(t)
    for lag in (1, 2, 3, 5):
        check(f"fast lag={lag}: {t[:20]!r}", fast_gated(t, lag), want)

# демонстрация, что старое поведение действительно теряет/портит текст
broken = sum(fast_naive(t, 2) != slow(t) for t in texts)
check("v1.0.2 naive ломается при lag=2 (ожидаемо)", broken > 0, True)

# предохранитель: завис воркер — клавиши не держим дольше MAX_HOLD
now = [0.0]
g = wg.KeyGate(clock=lambda: now[0])
g.begin()
check("gate держит в окне", g.offer({"vk": 65}), True)
now[0] = 1.0
check("gate отпускает после MAX_HOLD", g.offer({"vk": 66}), False)
check("gate.end отдаёт очередь", [e["vk"] for e in g.end()], [65])
check("gate свободен после end", g.busy, False)

# plan_replace
p = wg.plan_replace(2, "Ок.\n")
check("plan: 2 backspace = 4 события", [x[0] for x in p[:4]], [wg.VK_BACK] * 4)
check("plan: unicode без vk", [x[1] for x in p[4:10:2]], [ord("О"), ord("к"), ord(".")])
check("plan: Enter настоящий VK_RETURN", p[-2][0], wg.VK_RETURN)
check("plan: всё с меткой OURS", {x[3] for x in p}, {wg.EXTRA_OURS})
check("plan: эмодзи = суррогатная пара", len(wg.plan_replace(0, "😀")), 4)
check("plan: erase<0 не ломает", wg.plan_replace(-3, ""), [])
r = wg.plan_replay([{"vk": 65, "scan": 30}, {"vk": 65, "scan": 30, "up": True}])
check("replay: down/up + REPLAY", [(x[0], x[2], x[3]) for x in r],
      [(65, 0, wg.EXTRA_REPLAY), (65, wg.KEYEVENTF_KEYUP, wg.EXTRA_REPLAY)])

# раскладка
check("hkl ru", wg.layout_lang(0x04190419), "ru")
check("hkl en-US", wg.layout_lang(0x04090409), "en")
check("hkl en-GB", wg.layout_lang(0x08090809), "en")
check("hkl de", wg.layout_lang(0x04070407), "other")
lt = wg.LayoutTracker()
check("layout первый раз не смена", lt.changed(0x0419), False)
check("layout тот же", lt.changed(0x0419), False)
check("layout RU→EN = смена", lt.changed(0x0409), True)

# чёрный список / пароли / игры
bl = wg.build_blacklist()
check("vscode", wg.skip_reason(r"C:\Users\a\AppData\Local\Programs\Microsoft VS Code\Code.exe", bl, False, False), "blacklist")
check("terminal", wg.skip_reason("WindowsTerminal.exe", bl, False, False), "blacklist")
check("cmd", wg.skip_reason("C:/Windows/System32/cmd.exe", bl, False, False), "blacklist")
check("telegram ок", wg.skip_reason("Telegram.exe", bl, False, False), "")
check("пароль важнее всего", wg.skip_reason("Telegram.exe", bl, False, True), "password")
check("fullscreen игра", wg.skip_reason("SomeGame.exe", bl, True, False), "fullscreen")
check("fullscreen браузер ок", wg.skip_reason("chrome.exe", bl, True, False), "")
check("fullscreen geom", wg.is_fullscreen((0, 0, 1920, 1080), (0, 0, 1920, 1080)), True)
check("окно не fullscreen", wg.is_fullscreen((0, 0, 1920, 1040), (0, 0, 1920, 1080)), False)

tmp = os.path.join(here, "_bl_test.txt")
with open(tmp, "w", encoding="utf-8") as f:
    f.write("# мой список\nMyGame.exe\ncmd.exe\n-cmd.exe\n")
bl2 = wg.build_blacklist(tmp)
os.remove(tmp)
check("blacklist.txt добавляет", "mygame.exe" in bl2, True)
check("blacklist.txt убирает '-cmd.exe'", "cmd.exe" in bl2, False)

# фасад на не-Windows не падает
g2 = wg.WinGuard()
if sys.platform != "win32":
    check("WinGuard.context вне Windows", g2.context(force=True), ("", 0))

class D:  # имитация KBDLLHOOKSTRUCT
    def __init__(self, vk, extra=0):
        self.vkCode, self.scanCode, self.flags, self.dwExtraInfo = vk, 0, 0, extra

check("наше событие не в очередь", (g2.gate.begin(), g2.hold_if_busy(wg.WM_KEYDOWN, D(65, wg.EXTRA_OURS)))[1], False)
check("живое во время замены — в очередь", g2.hold_if_busy(wg.WM_KEYDOWN, D(66)), True)
# v1.0.3: replay во время НОВОЙ замены (её запустила переигранная клавиша) тоже ждёт
check("replay во время новой замены — в очередь", g2.hold_if_busy(wg.WM_KEYDOWN, D(67, wg.EXTRA_REPLAY)), True)
g2.replace(1, "x")
check("после replace очередь пуста", g2.gate.busy, False)
check("replay без замены идёт дальше", g2.hold_if_busy(wg.WM_KEYDOWN, D(66, wg.EXTRA_REPLAY)), False)

if sys.platform != "win32":
    check("should_skip вне Windows = False", wg.should_skip(), False)
check("blacklist.txt из модуля = стандартный", wg.build_blacklist(os.path.join(here, "blacklist.txt")), wg.DEFAULT_BLACKLIST)
print(f"\n{'OK' if not fails else 'FAILED'}: {fails} fail")
sys.exit(1 if fails else 0)
