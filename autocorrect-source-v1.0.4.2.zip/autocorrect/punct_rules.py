"""
punct_rules.py — расширенные правила запятых для автокорректора (кодер 2).

Работает по словам, в потоке (как печатает пользователь), без lookahead
дальше одного слова. Ничего не знает о клавиатуре: только слова.

Что умеет:
  * простые союзы и союзные слова: что, чтобы, но, а, если, когда, который…
  * составные союзы: так как, потому что, для того чтобы, после того как,
    несмотря на то что, в то время как, как будто, с тех пор как…
    (запятая ставится перед ВСЕЙ конструкцией, внутри — нет)
  * вводные слова и фразы: конечно, например, кстати, наверное, по-моему,
    к сожалению, во-первых, честно говоря, на самом деле, скорее всего…
    (с двух сторон; «вообще», «может», «может быть», «короче» — только в начале)
  * обращения: «привет мам», «спасибо витя», «мам я дома», «я дома мам»
  * исключения: «хотя бы», «что ли», «не то чтобы», «мне кажется что»,
    «может прийти» (глагол, а не вводное), «а кстати» (без запятой после а),
    «не только … но и» — запятая перед «но» ставится, как положено.

API для склейки (кодер 5):
    t = PunctTracker(names={"витя", ...})
    ks = t.on_word(raw_lower, printed)   # слово закончилось одним пробелом
    if ks: erase, text = t.edit_for(ks, raw_len, printed, trigger)
    t.reset()                            # знак препинания, Enter, клик, 2 пробела
См. INTEGRATION.md.

Чистая функция для тестов и QA: punctuate("это конечно хорошо") ->
"это, конечно, хорошо".
"""

from __future__ import annotations

import re
from typing import Iterable, List, Optional, Sequence, Tuple


def norm(word: str) -> str:
    return word.lower().replace("ё", "е")


import os

def _find_words_file(name="punct_words.txt"):
    """Рядом с exe (можно править без пересборки), потом внутри exe / рядом с модулем."""
    import sys
    dirs = []
    if getattr(sys, "frozen", False):
        dirs.append(os.path.dirname(os.path.abspath(sys.executable)))
    if getattr(sys, "_MEIPASS", None):
        dirs.append(sys._MEIPASS)
    dirs.append(os.path.dirname(os.path.abspath(__file__)))
    for d in dirs:
        p = os.path.join(d, name)
        if os.path.exists(p):
            return p
    return os.path.join(dirs[-1], name)


_WORDS_FILE = _find_words_file()


def _load(path: str = _WORDS_FILE) -> dict:
    secs: dict = {}
    cur = None
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.split("#", 1)[0].strip()
            if not line:
                continue
            if line.startswith("[") and line.endswith("]"):
                cur = secs.setdefault(line[1:-1], [])
            elif cur is not None:
                cur.append(norm(line))
    return secs


_S = _load()
COMMA_BEFORE = set(_S["COMMA_BEFORE"])
NO_COMMA_AFTER = set(_S["NO_COMMA_AFTER"])
COMPOUND_CONJ = [tuple(x.split()) for x in _S["COMPOUND_CONJ"]]
INTRO_ANYWHERE = [tuple(x.split()) for x in _S["INTRO_ANYWHERE"]]
INTRO_START_ONLY = [tuple(x.split()) for x in _S["INTRO_START_ONLY"]]
NO_COMMA_BEFORE_INTRO = set(_S["NO_COMMA_BEFORE_INTRO"])
GREETINGS = set(_S["GREETINGS"])
VOCATIVE_CLEAR = set(_S["VOCATIVE_CLEAR"])
VOCATIVE_AFTER_GREETING = VOCATIVE_CLEAR | set(_S["VOCATIVE_AFTER_GREETING"])
PREPOSITIONS = set(_S["PREPOSITIONS"])


def _pairs(rows):
    out = {}
    for r in rows:
        k, _, v = r.partition(":")
        out[k.strip()] = set(v.split())
    return out


DEFER_BLOCK = _pairs(_S["DEFER_BLOCK"])
NAMES = set(_S.get("NAMES", ()))
ADDRESS_CUE = set(_S.get("ADDRESS_CUE", ()))
REPEAT_CONJ = set(_S.get("REPEAT_CONJ", ()))
INTRO_PARTICLES = set(_S.get("INTRO_PARTICLES", ()))
KAK_AFTER_STEMS = tuple(_S.get("KAK_AFTER_STEMS", ()))
ASYNDETON_START = set(_S.get("ASYNDETON_START", ()))
_VERB_END = re.compile(r"(ю|у|ем|им|ешь|ишь|ет|ит|ут|ют|ат|ят|ал|ял|ел|ил|ла|ли|ло|ся|сь)$")
_SUBJ = {"я", "ты", "он", "она", "мы", "вы", "они"}
_NOT_VERB = {"я", "ты", "он", "она", "оно", "мы", "вы", "они", "мне", "тебе", "ему", "ей",
             "нам", "вам", "им", "его", "ее", "их", "уже", "еще", "тут", "там", "дому",
             "тебя", "меня", "ли", "куда", "минут", "часу"}
PAIRED = {k: next(iter(v)) for k, v in _pairs(_S.get("PAIRED", ())).items() if v}
INTRO_NOT_AFTER = _pairs(_S["INTRO_NOT_AFTER"])


def _match_tail(words: Sequence[str], phrase: Tuple[str, ...]) -> bool:
    n = len(phrase)
    return len(words) >= n and tuple(words[-n:]) == phrase


class PunctTracker:
    """Поток слов одной клаузы (от начала предложения или последнего знака)."""

    def __init__(self, names: Optional[Iterable[str]] = None):
        self.names = NAMES | {norm(n) for n in (names or ())}
        self.reset()

    def reset(self):
        self.words: List[str] = []      # норм. формы
        self.printed: List[str] = []    # как напечатано на экране
        self.comma_before: set = set()  # индексы слов, перед которыми запятая
        self.pending: Optional[int] = None   # отложенный союз: индекс слова
        self.intro_end: Optional[int] = None  # вводное закончилось на этом индексе
        self.voc_end: Optional[int] = None    # обращение закончилось на этом индексе

    # ---- внутреннее ----------------------------------------------------
    def _mark(self, i: int, out: List[int]):
        if i >= 1 and i not in self.comma_before:
            self.comma_before.add(i)
            out.append(len(self.words) - 1 - i)

    def _base_allows(self, i: int) -> bool:
        w = self.words[i]
        if w not in COMMA_BEFORE or i < 1:
            return False
        prev = self.words[i - 1]
        if prev in NO_COMMA_AFTER:
            return False
        # слово внутри уже начатого составного союза — не трогаем
        for comp in COMPOUND_CONJ:
            for cut in range(1, len(comp)):
                if comp[cut] == w and i - cut >= 0 and tuple(self.words[i - cut:i]) == comp[:cut]:
                    return False
        return True

    # ---- основной вход -------------------------------------------------
    def on_word(self, raw: str, printed: Optional[str] = None) -> List[int]:
        """Слово закончено. Возвращает список k: поставить «, » перед словом,
        стоящим на k позиций назад (0 — текущее слово)."""
        w = norm(raw)
        self.words.append(w)
        self.printed.append(printed if printed is not None else raw)
        i = len(self.words) - 1
        out: List[int] = []

        # 1) отложенный союз с прошлого слова
        if self.pending is not None:
            p = self.pending
            self.pending = None
            if w not in DEFER_BLOCK.get(self.words[p], ()):
                self._mark(p, out)

        # 2) запятая ПОСЛЕ вводного / обращения = перед текущим словом
        intro = self._intro_match()
        if self.intro_end is not None and self.intro_end == i - 1:
            extends = intro is not None and intro > 1 and (i - intro + 1) <= self.intro_end
            modal_verb = self.words[i - 1] == "может" and self._is_infinitive(w)
            if w in INTRO_PARTICLES and not extends:
                self.intro_end = i          # «конечно же, …»
            elif not extends and not modal_verb:
                self._mark(i, out)
        if self.voc_end is not None and self.voc_end == i - 1:
            self._mark(i, out)
        if self.intro_end != i:
            self.intro_end = None
        self.voc_end = None

        # 3) составные союзы (ставим перед первым словом конструкции)
        compound_hit = False
        for comp in sorted(COMPOUND_CONJ, key=len, reverse=True):
            if _match_tail(self.words, comp):
                start = i - len(comp) + 1
                compound_hit = True
                if start >= 1 and self.words[start - 1] not in NO_COMMA_AFTER:
                    self._mark(start, out)
                # перед внутренними словами запятых быть не должно
                break

        # 3b) предлог + «который/чей»: запятая перед предлогом («дом, в котором»)
        if (not compound_hit and i >= 2 and (w.startswith("котор"))
                and self.words[i - 1] in PREPOSITIONS
                and self.words[i - 2] not in PREPOSITIONS
                and self.words[i - 2] not in NO_COMMA_AFTER):
            self._mark(i - 1, out)
            compound_hit = True

        # 3c) «помню, как», «видел, как»
        if (not compound_hit and w == "как" and i >= 1
                and self.words[i - 1].startswith(KAK_AFTER_STEMS)):
            self._mark(i, out)
        # 3d) бессоюзное: «я уже выхожу, буду через десять минут»
        if (not compound_hit and w in ASYNDETON_START and i >= 2
                and self.words[i - 1] not in _NOT_VERB
                and self.words[i - 1] not in NO_COMMA_AFTER
                and _VERB_END.search(self.words[i - 1])
                and any(x in _SUBJ for x in self.words[:i - 1])):
            self._mark(i, out)

        # 4) простые союзы
        if not compound_hit and self._base_allows(i):
            if w in DEFER_BLOCK:
                self.pending = i
            else:
                self._mark(i, out)

        # 5) вводные слова
        if intro is not None:
            start = i - intro + 1
            prev = self.words[start - 1] if start >= 1 else None
            if prev is not None and prev not in NO_COMMA_BEFORE_INTRO:
                self._mark(start, out)
            self.intro_end = i
        # 6) обращения
        self._vocative(i, out)
        # 7) имя/обращение в начале фразы + признак обращения: «аня, позвони»
        if i == 1:
            w0 = self.words[0]
            if (w0 in self.names or w0 in VOCATIVE_AFTER_GREETING) and (
                    w in ADDRESS_CUE or self._is_imperative(w)):
                self._mark(1, out)
        # 8) повторяющиеся и парные союзы: «и он, и я», «то дождь, то снег»,
        #    «чем больше, тем лучше», «как он, так и я»
        if i >= 2:
            w0 = self.words[0]
            if w == w0 and w in REPEAT_CONJ:
                self._mark(i, out)
            elif PAIRED.get(w0) == w:
                self._mark(i, out)

        out.sort()
        return out

    def _intro_match(self) -> Optional[int]:
        """Длина совпавшей вводной фразы, оканчивающейся текущим словом."""
        i = len(self.words) - 1
        for phrase in sorted(INTRO_ANYWHERE, key=len, reverse=True):
            if _match_tail(self.words, phrase):
                start = i - len(phrase) + 1
                prev = self.words[start - 1] if start >= 1 else None
                if prev in INTRO_NOT_AFTER.get(phrase[0], ()):
                    return None
                if prev in PREPOSITIONS and len(phrase) == 1:
                    return None
                return len(phrase)
        for phrase in sorted(INTRO_START_ONLY, key=len, reverse=True):
            if _match_tail(self.words, phrase):
                start = i - len(phrase) + 1
                lead = self.words[:start]
                if all(x in NO_COMMA_BEFORE_INTRO for x in lead) and len(lead) <= 1:
                    return len(phrase)
        return None

    def _vocative(self, i: int, out: List[int]):
        w = self.words[i]
        prev = self.words[i - 1] if i >= 1 else None
        is_name = w in self.names
        if prev in GREETINGS and (w in VOCATIVE_AFTER_GREETING or is_name):
            if not (prev in {"пока"} and w in {"все"}):
                self._mark(i, out)
                self.voc_end = i
            return
        if w in VOCATIVE_CLEAR:
            if i == 0:
                self.voc_end = i            # «мам я дома» -> «мам, я дома»
            elif prev not in PREPOSITIONS and prev not in NO_COMMA_AFTER:
                self._mark(i, out)          # «я дома мам» -> «я дома, мам»
                self.voc_end = i

    def _is_imperative(self, w: str) -> bool:
        return len(w) >= 4 and bool(re.search(r"(ни|ри|ди|жи|ви|ми|ти|ай|ей|йте|ите)$", w))

    # «может прийти» — глагол, а не вводное.
    def _is_infinitive(self, w: str) -> bool:
        return w != "быть" and bool(re.search(r"(ть|ти|чь|ться|тись)$", w))

    def finish(self) -> List[int]:
        """Клауза закончилась (знак/Enter). Отложенное «что/хотя» в конце не ставим."""
        self.pending = None
        return []

    # ---- построение правки для клавиатурного движка --------------------
    def edit_for(self, ks: Sequence[int], raw_len: int, fixed: str,
                 trigger: str, end_mark: str = "") -> Tuple[int, str]:
        """(сколько стереть, что напечатать) — как в Corrector._flush.

        Предполагается, что слова клаузы разделены ровно одним пробелом и
        текущее слово напечатано сырым (raw_len символов) + trigger.
        """
        n = max(ks)
        prev = self.printed[-1 - n:-1] if n else []
        erase = raw_len + len(trigger) + sum(len(p) + 1 for p in prev) + 1
        parts = []
        seq = prev + [fixed]
        for j, word in enumerate(seq):
            k = n - j
            parts.append((", " if k in ks else " ") + word)
        self.printed[-1] = fixed
        return erase, "".join(parts) + end_mark + trigger


# --- чистая функция для тестов / QA --------------------------------------
_SPLIT = re.compile(r"([.!?;:,\n]+)")


def punctuate(text: str, names: Optional[Iterable[str]] = None) -> str:
    """Расставить запятые в готовом тексте теми же правилами, что и в потоке."""
    out = []
    t = PunctTracker(names)
    for chunk in _SPLIT.split(text):
        if not chunk:
            continue
        if _SPLIT.fullmatch(chunk):
            t.reset()
            out.append(chunk)
            continue
        lead = len(chunk) - len(chunk.lstrip(" "))
        trail = len(chunk) - len(chunk.rstrip(" "))
        words = chunk.split()
        commas: set = set()
        t.reset()
        for idx, word in enumerate(words):
            for k in t.on_word(word):
                commas.add(idx - k)
        body = ""
        for idx, word in enumerate(words):
            if idx == 0:
                body = word
            else:
                body += (", " if idx in commas else " ") + word
        out.append(" " * lead + body + " " * trail)
    return "".join(out)


# --- API по договорённости с кодером 5 -----------------------------------
def comma_before(prev_words: List[str], word: str, names: Optional[Iterable[str]] = None) -> bool:
    """Ставить ли запятую перед word (набор на лету, без состояния).

    prev_words — слова текущей клаузы до word (после последнего знака).
    Отложенные слова (что/хотя/где…) тут решаются сразу, как в v1.0.2;
    полная точность («что ли», «хотя бы», «так как», запятая после вводного
    перед длинной связкой) — через PunctTracker, см. INTEGRATION.md.
    """
    t = PunctTracker(names)
    for w in prev_words:
        t.on_word(w)
    ks = t.on_word(word)
    if 0 in ks:
        return True
    return t.pending == len(t.words) - 1


def fix_punct(text: str, names: Optional[Iterable[str]] = None) -> str:
    """Расставить запятые во всём тексте."""
    return punctuate(text, names)
