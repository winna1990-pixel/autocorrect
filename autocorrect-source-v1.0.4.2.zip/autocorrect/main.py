"""
Автокорректор для ПК — vitaa_games, v1.0.3.
Заглавные в начале предложения и у имён, точки (Enter, двойной пробел,
новое предложение с заглавной, по желанию — пауза), запятые перед союзами,
исправление опечаток по dictionary.txt и большому офлайн-словарю (spell.py).
Ctrl+Alt+C — исправить выделенный текст целиком. Полностью офлайн.
"""

import json
import re
import logging
import os
import sys
import threading
import time
try:
    import tkinter as tk
    from tkinter import ttk
except ImportError:  # только для тестов логики без GUI
    tk = ttk = None

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("AutoCorrect")

VERSION = "1.0.4.2"
SENTENCE_END = ".!?"
PUNCT = ".,!?;:"
AUTO_SPACE = ",;!?"
# v1.0.4: ссылки, почта, @ник, #тег — не трогаем вообще (держим токен до пробела)
HOLD_INSIDE = PUNCT + "/@#=&"  # после этого символа внутри токена — ждём пробел
HOLD_START = ":;=@#"  # токен, начатый с них, тоже ждём (смайлики, @ник, #тег)
RAW_TAIL = ".,!?;:"  # знаки в конце ссылки — это уже текст, а не ссылка
EMOTICON = re.compile(r"^(?:[:;=8][-'^oо]?[)(DdРрPpOoОо3*|\\/\]\[]+|[)(]{2,}|\^_*\^|<3|[xXхХ][DdДд]+)$")


def is_raw_token(tok: str) -> bool:
    """Ссылка, почта, @ник или #тег — оставить как набрано."""
    low = tok.lower()
    return ("://" in low or low.startswith("www.") or "@" in low
            or (low.startswith("#") and len(low) > 1))  # не '.' и ':' — чтобы не ломать site.ru и 12:30
PAUSE_SECONDS = 2.0


def app_dir() -> str:
    """Папка рядом с exe (PyInstaller) или рядом с main.py."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def bundled_dir() -> str:
    return getattr(sys, "_MEIPASS", app_dir())


def find_data_file(name: str) -> str:
    """Сначала рядом с exe (можно править), потом встроенный в exe."""
    for d in (app_dir(), bundled_dir()):
        p = os.path.join(d, name)
        if os.path.exists(p):
            return p
    return ""


def find_dictionary() -> str:
    return find_data_file("dictionary.txt")


def load_dictionary(path: str):
    fixes, names = {}, set()
    if not path:
        logger.warning("dictionary.txt не найден")
        return fixes, names
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                if line.startswith("!"):
                    names.add(line[1:].strip().lower())
                elif "=" in line:
                    wrong, right = line.split("=", 1)
                    if wrong.strip():
                        fixes[wrong.strip().lower()] = right.strip()
        logger.info("Словарь: %d исправлений, %d имён", len(fixes), len(names))
    except Exception as exc:
        logger.error("Ошибка загрузки словаря: %s", exc)
    return fixes, names


def upper_first(s: str) -> str:
    return s[:1].upper() + s[1:] if s else s


# ---------- правила пунктуации (punctuation.txt) ----------

class PunctRules:
    """Списки из punctuation.txt. Логика запятых — в CommaRules (легко заменить)."""

    SECTIONS = {
        "запятая перед": "comma_before",
        "без запятой после": "no_comma_after",
        "без запятой после местоимения": "no_comma_after_pronoun",
        "местоимения": "pronouns",
        "точка перед заглавной": "period_starters",
        "сокращения": "abbreviations",
        "без точки после": "no_period_after",
        "запятая перед как после": "kak_verbs",
        "без запятой перед который после": "no_comma_before_kotor",
    }

    def __init__(self):
        for attr in self.SECTIONS.values():
            setattr(self, attr, set())
        self.phrases = []  # кортежи слов, самые длинные первыми

    @classmethod
    def from_file(cls, path: str):
        r = cls()
        cur = None
        with open(path, "r", encoding="utf-8-sig") as f:
            for raw in f:
                line = raw.strip().lower()
                if not line or line.startswith("#"):
                    continue
                if line.startswith("[") and line.endswith("]"):
                    cur = cls.SECTIONS.get(line[1:-1].strip())
                    continue
                if cur:
                    getattr(r, cur).add(" ".join(line.split()))
        r.phrases = sorted((tuple(p.split()) for p in r.comma_before), key=len, reverse=True)
        return r


def find_punctuation() -> str:
    return find_data_file("punctuation.txt")


def load_punctuation(path: str = None) -> PunctRules:
    path = path if path is not None else find_punctuation()
    try:
        if path:
            r = PunctRules.from_file(path)
            logger.info("Пунктуация: %d союзов, %d сокращений", len(r.comma_before), len(r.abbreviations))
            return r
    except Exception as exc:
        logger.error("Ошибка загрузки punctuation.txt: %s", exc)
    logger.warning("punctuation.txt не найден — запятые не расставляются")
    return PunctRules()


# ---------- имена в падежах ----------

def name_forms(name: str):
    """Простые падежные формы имени: витя -> вити, вите, витю, витей…"""
    forms = {name}
    if len(name) < 3:
        return forms
    if name.endswith("ия"):
        st = name[:-1]
        forms |= {st + e for e in ("и", "ю", "ей", "ею")}
    elif name.endswith("я"):
        st = name[:-1]
        forms |= {st + e for e in ("и", "е", "ю", "ей", "ею")}
    elif name.endswith("а"):
        st = name[:-1]
        tail = "и" if st[-1:] in "гкхжчшщ" else "ы"
        forms |= {st + e for e in (tail, "е", "у", "ой", "ою")}
    elif name.endswith(("ь", "й")):
        st = name[:-1]
        forms |= {st + e for e in ("я", "ю", "ем", "е", "и")}
    elif name[-1:].isalpha() and name[-1] not in "аеёиоуыэюя":
        forms |= {name + e for e in ("а", "у", "ом", "е", "ы", "ов")}
    return forms


def expand_names(names):
    out = set()
    for n in names:
        out |= name_forms(n)
    return out


def _is_cyr_word(w: str) -> bool:
    return bool(w) and all(("а" <= c <= "я") or c == "ё" for c in w.lower())


class CommaRules:
    """Где поставить запятую перед только что законченным словом.

    run — слова текущего отрезка (без знаков между ними), последнее — текущее.
    Возвращает индекс слова, перед которым нужна запятая, или None.
    Чтобы подключить другой модуль правил, достаточно заменить этот класс.
    """

    def __init__(self, rules: PunctRules):
        self.r = rules

    def comma_indices(self, run, has_comma):
        """Список индексов слов, перед которыми нужна запятая (новые и уже стоящие)."""
        ci = self.comma_index(run, has_comma)
        return [] if ci is None else [ci]

    def comma_index(self, run, has_comma):
        n = len(run)
        if n >= 2 and run[-1] == "как" and run[-2] in self.r.kak_verbs and not has_comma[-1]:
            return n - 1  # «помню, как мы гуляли», «видел, как он бежал»
        for ph in self.r.phrases:
            k = len(ph)
            if k > n or tuple(run[n - k:]) != ph:
                continue
            i = n - k
            if i == 0:
                return None  # фраза в начале предложения — без запятой
            if any(has_comma[i:n]):
                return None  # запятая уже стоит («, потому что»)
            prev = run[i - 1]
            if prev in self.r.no_comma_after:
                return None
            if k == 1 and run[-1] in self.r.no_comma_after_pronoun and prev in self.r.pronouns:
                return None  # «ты где», «а ты куда»
            if k == 1 and run[-1].startswith("котор") and prev in self.r.no_comma_before_kotor:
                return None  # «сегодня который день» — вопрос, а не придаточное
            return i
        return None


COMMA_WINDOW = 6  # запятую ставим не дальше, чем за 6 слов назад


class PunctTrackerRules:
    """Запятые по punct_rules.py (кодер 2): вводные, обращения, составные союзы.

    Без своего состояния: на каждом слове заново прогоняет PunctTracker по словам
    отрезка (отрезок обнуляется на знаках, Enter, клике, Backspace — это и есть
    reset() из INTEGRATION.md). Слово из словаря вида «потому что» делится на части.
    """

    MAX_WORDS = 30

    def __init__(self, names=()):
        from punct_rules import PunctTracker
        self._cls = PunctTracker
        self.names = set(names)

    def comma_indices(self, run, has_comma):
        run = list(run)[-self.MAX_WORDS:]
        shift = len(has_comma) - len(run)
        t = self._cls(names=self.names)
        owner, marks = [], set()
        for ri, entry in enumerate(run):
            for pi, tok in enumerate(entry.split()):
                owner.append((ri, pi == 0))
                for k in t.on_word(tok):
                    oi = len(owner) - 1 - k
                    if 0 <= oi and owner[oi][1]:
                        marks.add(owner[oi][0] + shift)
        return sorted(marks)


class HybridCommaRules:
    """Объединение: наши правила (punctuation.txt) + правила кодера 2 (punct_rules.py).

    * Вводные слова, обращения, «дом, в котором», составные союзы — от кодера 2.
    * Перед простыми союзами (что, где, который…) решают НАШИ правила: кодер 2
      ставит запятую туда только если наши согласны («ты что делаешь», «сегодня
      который день» — без запятой). Выбрано по корпусу.
    * «что/хотя/где/куда/почему/зачем/когда/чем» — как у кодера 2, на следующем
      слове («что ли», «хотя бы», «ты где» без запятой).
    """

    def __init__(self, ours, theirs, defer=()):
        self.ours, self.theirs = ours, theirs
        self.defer = set(defer)
        self.conj = {p[0] for p in ours.r.phrases if len(p) == 1}

    def _ours_at(self, run, has_comma, i):
        return self.ours.comma_index(run[:i + 1], has_comma[:i + 1]) == i

    def comma_indices(self, run, has_comma):
        n = len(run)
        out = set()
        for i in self.ours.comma_indices(run, has_comma):
            if i == n - 1 and run[i] in self.defer:
                continue  # решим на следующем слове
            out.add(i)
        for i in self.theirs.comma_indices(run, has_comma):
            if run[i] in self.conj and not self._ours_at(run, has_comma, i):
                continue  # наши правила против
            out.add(i)
        return sorted(out)


def make_comma_rules(rules, names=()):
    ours = CommaRules(rules)
    try:
        theirs = PunctTrackerRules(names)
        from punct_rules import DEFER_BLOCK
    except Exception as exc:  # нет punct_rules.py / punct_words.txt — только свои правила
        logger.warning("punct_rules недоступен: %s", exc)
        return ours
    return HybridCommaRules(ours, theirs, DEFER_BLOCK)


# «ложи» — повелительное (-> «положи») только в начале фразы или после этих слов
LOZHI_PREV = {"ты", "вы", "не", "пожалуйста", "давай", "просто", "сюда", "туда", "его", "её",
              "ее", "их", "это", "а", "и", "но", "ну", "тогда", "лучше", "быстрее", "ещё", "уже"}

try:
    import questions as _q  # v1.0.4: «?» в конце вопроса и запятые «по смыслу»
except Exception:  # noqa: BLE001 — без файла работаем как 1.0.3
    _q = None


class Corrector:
    """Чистая логика без клавиатуры — удобно тестировать.

    feed_* возвращают None или (сколько символов стереть, что напечатать).
    clock — функция времени (для правила «точка после паузы»), в тестах подменяется.
    """

    def __init__(self, fixes=None, names=None, rules: PunctRules = None, spell=None,
                 clock=time.monotonic, pause_period=False, pause_seconds=PAUSE_SECONDS,
                 settings=None, comma_rules=None):
        self.fixes = fixes or {}
        self.names = set(names or ())
        self.name_forms = expand_names(self.names)
        self.rules = rules if rules is not None else PunctRules()
        # Логика запятых подключаемая: по умолчанию — гибрид правил кодера 2 и наших
        self.commas = comma_rules if comma_rules is not None else make_comma_rules(self.rules, self.names)
        self.spell = spell  # SpellEngine или None (пока словарь грузится)
        self.clock = clock
        self.pause_period = pause_period  # точка после паузы 2 с
        self.pause_seconds = pause_seconds
        self.double_space = True  # точка по двойному пробелу
        self.commas_on = True
        self.spelling = True
        self.questions_on = True  # «?» вместо «.» в конце вопроса
        self.settings = settings  # ui.Settings / dict: commas, spelling, pause_period
        self.apply_settings()
        self.reset()

    def apply_settings(self):
        """Галочки из settings.json (вызывается и при живом переключении)."""
        s = self.settings
        if s is None:
            return
        self.commas_on = bool(s["commas"])
        self.spelling = bool(s["spelling"])
        self.pause_period = bool(s["pause_period"])
        self.double_space = bool(s["pause_period"])
        try:
            self.questions_on = bool(s["questions"])
        except (KeyError, TypeError):
            self.questions_on = True

    def reset(self):
        self.buffer = ""
        self.need_capitalize = True
        self.spaces = 0  # пробелов подряд
        self.space_after_word = False  # эти пробелы идут сразу после слова
        self.last_punct = ""  # знак, напечатанный прямо перед текущим символом
        self.before_punct = ""  # слово перед этим знаком
        self.glued = False  # слово прилипло к точке/двоеточию: site.ru, 12:30
        self.run = []  # слова отрезка без знаков: [(lower, на экране, есть ли запятая перед)]
        self.gap_space = False  # текущее слово идёт сразу после «слово␣»
        self.paused = False  # перед текущим словом была пауза
        self.last_space_time = 0.0
        self.sentence_words = 0  # слов в текущем предложении
        self.sent = []  # слова предложения [(lower, запятая перед)]; None — начало неизвестно
        self.sep_pending = False  # человек сам поставил , ; : перед следующим словом
        self.undo = None  # (длина нашей замены, что было) — для отмены Backspace
        self.tok = ""  # токен с последнего пробела (как набран)
        self.pend = ""  # его часть, ещё не обработанная (ждём пробел)
        self.shadow = ""  # хвост экрана, как мы его видим (для сборки одной замены)
        self.raw = False  # следующий _flush — ссылка/смайлик: не трогать
        self.raw_emoticon = False
        self.after_emoticon = False  # предложение кончилось смайликом: точку не ставим

    # --- слова ---

    def is_name(self, lower: str) -> bool:
        return lower in self.name_forms

    def is_abbrev(self, word: str) -> bool:
        lw = word.lower()
        if len(lw) == 1 and lw.isalpha():
            return lw != "я"
        return lw in self.rules.abbreviations

    def correct_word(self, word: str, capitalize: bool) -> str:
        lower = word.lower()
        out = word
        mixed = any(c.isupper() for c in word[1:])  # iPhone, McDonald, НАТО
        if not self.spelling:
            pass  # «Орфография» выключена: только заглавные
        elif lower in self.fixes:
            out = self.fixes[lower]
            if word[:1].isupper():
                out = upper_first(out)
        elif (
            self.spell is not None and not mixed and not self.glued
            and not self.is_name(lower) and _is_cyr_word(word)
        ):
            fix = self.spell.correct(lower)
            if fix:
                out = upper_first(fix) if word[:1].isupper() else fix
        if (capitalize or self.is_name(lower)) and not mixed:
            out = upper_first(out)
        return out

    def _phrase_fix(self, lower, gap, trigger, end_mark, word):
        """Исправления из двух слов: «кто нибудь» -> «кто-нибудь», «тока что» -> «только что»."""
        if not (gap and self.run and self.spelling):
            return None
        prev_key, prev_screen, hc = self.run[-1]
        repl = self.fixes.get(prev_key + " " + lower)
        if not repl:
            return None
        out = upper_first(repl) if prev_screen[:1].isupper() else repl
        self.run[-1] = (repl.lower(), out, hc)
        if self.sent:
            self.sent[-1] = (repl.lower(), self.sent[-1][1])
        self.sep_pending = False
        if end_mark == ".":
            end_mark = self._end_mark()
        erase = len(prev_screen) + 1 + len(word) + len(trigger)
        text = out + end_mark + trigger
        if trigger != " ":
            self.run = []
        else:
            self.undo = (len(text), prev_screen + " " + word + trigger)
        return (erase, text)

    def _known(self):
        sp = self.spell
        return sp.known if sp is not None and hasattr(sp, "known") else None

    def _end_mark(self) -> str:
        """Чем закончить предложение: «?» для вопроса, иначе «.»."""
        if (_q is not None and self.questions_on and self.sent
                and _q.is_question(self.sent, self.is_name, self._known())):
            return "?"
        return "."

    def _sent_add(self, key: str, comma: bool):
        if self.sent is not None:
            self.sent.append((key, comma or self.sep_pending))
        self.sep_pending = False

    def _sent_mark(self, run_len: int, idxs):
        """Наши новые запятые перед словами отрезка run (индексы в run) — в self.sent."""
        if not self.sent or not idxs:
            return
        base = len(self.sent) - run_len
        for i in idxs:
            j = base + i
            if 0 <= j < len(self.sent):
                self.sent[j] = (self.sent[j][0], True)

    def _flush_raw(self, word, trigger, end_mark):
        """Ссылка/почта/ник/смайлик: как набрано, без заглавной, запятых и орфографии."""
        emo = self.raw_emoticon or bool(EMOTICON.match(word))
        self.raw = self.raw_emoticon = False
        cap = self.need_capitalize
        self.need_capitalize = False
        self.gap_space = self.paused = self.glued = False
        self.sentence_words = 1 if cap else self.sentence_words + 1
        if cap:
            self.sent = []
        if self.sent is not None:
            self.sent.append(("\x00", self.sep_pending))
        self.sep_pending = False
        self.run = []
        self.after_emoticon = emo
        if emo or not end_mark:
            return None
        if end_mark == ".":
            end_mark = self._end_mark()
        return (len(trigger), end_mark + trigger)

    def _period_before(self, word: str, lower: str) -> bool:
        """Нужна ли точка перед словом посреди предложения."""
        if not self.run or not self.gap_space:
            return False
        prev = self.run[-1][0]
        if prev in self.rules.no_comma_after:
            return False  # «в Москве», «и Я»…
        mixed = any(c.isupper() for c in word[1:])
        if (word[:1].isupper() and not mixed and not self.is_name(lower)
                and lower in self.rules.period_starters):
            return True  # «привет Как дела»
        if (
            self.paused and self.sentence_words >= 3
            and lower not in self.rules.comma_before
            and prev not in self.rules.no_period_after
            and prev not in self.rules.comma_before
        ):
            return True  # пауза >= 2 с после 3+ слов (можно выключить)
        return False

    def _flush(self, trigger: str, end_mark: str = ""):
        """Слово закончилось символом trigger (он уже напечатан пользователем).

        end_mark — знак, который надо вставить между словом и trigger (точка на Enter).
        """
        word = self.buffer
        self.buffer = ""
        cap = self.need_capitalize
        gap = self.gap_space
        if word and (self.raw or EMOTICON.match(word)):
            return self._flush_raw(word, trigger, end_mark)
        if not word:
            self.paused = False
            self.gap_space = False
            self.glued = False
            return None
        self.after_emoticon = False
        lower = word.lower()
        self.gap_space = gap
        period = not cap and self._period_before(word, lower)
        self.gap_space = False
        self.paused = False
        prev_mark = "."
        if period:
            prev_mark = self._end_mark()  # «как дела ⏸ты где» -> «Как дела? Ты где»
            cap = True
            self.run = []
        self.sentence_words = 1 if cap else self.sentence_words + 1
        if cap:
            self.sent = []
            self.sep_pending = False
        if not gap:
            self.run = []
        self.need_capitalize = False
        fixed = self.correct_word(word, cap)
        if (self.spelling and lower == "ложи" and not self.glued
                and (cap or (gap and self.run and self.run[-1][0] in LOZHI_PREV))):
            # «ложи телефон» -> «положи»; «в ложи театра» (существительное) не трогаем
            fixed = "Положи" if (cap or word[:1].isupper()) else "положи"
        self.glued = False
        phrase = self._phrase_fix(lower, gap, trigger, end_mark, word)
        if phrase is not None:
            return phrase
        key = fixed.lower() if fixed.lower().replace(" ", "") else lower
        run_words = [w for w, _, _ in self.run] + [key]
        has_comma = [c for _, _, c in self.run] + [False]
        n = len(run_words)
        idxs = []
        if not (period or cap or not gap or not self.commas_on):
            cand = set(self.commas.comma_indices(run_words, has_comma))
            if _q is not None:
                sent_start = len(self.run) + 1 == self.sentence_words
                cand |= _q.extra_commas(run_words, has_comma, sent_start,
                                        bool(end_mark), self.is_name, self._known())
            idxs = sorted({i for i in cand
                           if 1 <= i < n and not has_comma[i] and i >= n - COMMA_WINDOW
                           # «пока что» — частица: «Пока что подожди», не «Пока, что…»
                           and not (run_words[i] == "что" and run_words[i - 1] == "пока")
                           # «если …, то» — решим на следующем слове («то, что» — без запятой)
                           and not (run_words[i] == "то" and "если" in run_words[:i]
                                    and (i == n - 1 or run_words[i + 1] in ("что", "есть")))})
        self._sent_add(key, False)
        self._sent_mark(n, idxs)
        if end_mark == ".":
            end_mark = self._end_mark()
        if idxs:
            # «знаю что␣» -> «знаю, что␣»: стираем от пробела перед первым словом с новой запятой
            m = idxs[0]
            new = set(idxs)
            screens = [s for _, s, _ in self.run[m:]]
            old = has_comma[m:]
            erase = sum((2 if c else 1) + len(sc) for sc, c in zip(screens + [word], old)) + len(trigger)
            text = "".join((", " if (c or (m + j) in new) else " ") + sc
                           for j, (sc, c) in enumerate(zip(screens + [fixed], old))) + end_mark + trigger
            original = "".join((", " if c else " ") + sc for sc, c in zip(screens + [word], old)) + trigger
            self.run = self.run[:m] + [(w, s, c or (m + j) in new) for j, (w, s, c) in enumerate(self.run[m:])]
            self.run.append((key, fixed, (n - 1) in new))
            action = (erase, text)
        elif period:
            self.run = [(key, fixed, False)]
            action = (len(word) + len(trigger) + 1, prev_mark + " " + fixed + end_mark + trigger)
            original = " " + word + trigger
        else:
            self.run.append((key, fixed, False))
            action = None if (fixed == word and not end_mark) else (len(word) + len(trigger), fixed + end_mark + trigger)
            original = word + trigger
        if trigger != " ":
            self.run = []
        elif action:
            self.undo = (len(action[1]), original)
        return action

    # --- клавиши ---

    def _feed_char(self, ch: str):
        self.undo = None
        if ch in PUNCT:
            self.spaces = 0
            self.space_after_word = False
            word = self.buffer
            self.before_punct = word
            action = self._flush(ch)
            self.run = []
            self.sep_pending = ch in ",;:"
            self.last_punct = ch
            if ch in SENTENCE_END and not (ch == "." and word and self.is_abbrev(word)):
                self.need_capitalize = True
            return action
        if ch.isspace():
            return self._feed_space() if ch == " " else None
        punct, prev = self.last_punct, self.before_punct
        self.last_punct = ""
        if not self.buffer:
            self.gap_space = self.spaces == 1 and self.space_after_word and bool(self.run)
            if not self.gap_space:
                self.run = []
            elif self.pause_period and self.clock() - self.last_space_time >= self.pause_seconds:
                self.paused = True
            self.glued = bool(punct) and punct not in AUTO_SPACE
        self.spaces = 0
        self.space_after_word = False
        if punct == "." and not self.buffer and ch.isalpha() and _is_cyr_word(ch) \
                and _is_cyr_word(prev) and len(prev) >= 2 and not self.is_abbrev(prev):
            # «ок.понял» -> «ок. Понял» (site.ru, т.е., 1.5 не трогаем)
            self.glued = False
            self.need_capitalize = True
            self.buffer = ch.upper()
            return (1, " " + ch.upper())
        if punct and punct not in AUTO_SPACE and not self.buffer:
            self.need_capitalize = False  # site.ru, file.txt, т.е., 12:30
        self.buffer += ch
        if punct in AUTO_SPACE and punct and ch.isalpha() and prev:
            # "спс,пака" -> "спс, пака" (числа вроде 1,5 не трогаем)
            return (1, " " + ch)
        return None

    def _feed_space(self):
        self.undo = None
        self.last_punct = ""
        had_word = bool(self.buffer)
        action = self._flush(" ")
        if had_word:
            self.spaces = 1
            self.space_after_word = True
            self.last_space_time = self.clock()
            return action
        self.spaces += 1
        if (self.spaces == 2 and self.space_after_word and not self.need_capitalize
                and self.double_space and not self.after_emoticon):
            # "слово␣␣" -> "слово. " (или «? » для вопроса)
            mark = self._end_mark()
            self.need_capitalize = True
            self.spaces = 0
            self.space_after_word = False
            self.run = []
            return (2, mark + " ")
        self.run = []
        return None

    def _feed_enter(self):
        self.undo = None
        self.last_punct = ""
        if self.buffer:
            # «слово⏎» -> «слово.⏎»; после ссылки точку не ставим — ломает ссылку (v1.0.4.1)
            link = self.raw and not self.raw_emoticon
            action = self._flush("\n", end_mark="" if link else ".")
        elif (self.spaces == 1 and self.space_after_word and not self.need_capitalize
              and not self.after_emoticon):
            # «слово␣⏎» -> «слово.⏎»
            action = (2, self._end_mark() + "\n")
        else:
            action = None
        self.spaces = 0
        self.space_after_word = False
        self.run = []
        self.gap_space = False
        self.need_capitalize = True
        return action

    def _feed_backspace(self):
        undo, self.undo = self.undo, None
        if undo and not self.buffer:
            self.break_context()
            erase, original = undo
            return (erase - 1, original)  # один символ уже стёр сам Backspace
        self.last_punct = ""
        self.spaces = 0
        self.space_after_word = False
        self.run = []
        self.gap_space = False
        self.paused = False
        if self.buffer:
            self.buffer = self.buffer[:-1]
        else:
            self.sent = None  # стёрли пробел/знак/слово: что в предложении — уже не знаем

    def break_context(self):
        """Стрелки, клик, Tab, хоткеи — контекст потерян, ничего не правим."""
        self.undo = None
        self.last_punct = ""
        self.buffer = ""
        self.spaces = 0
        self.space_after_word = False
        self.run = []
        self.gap_space = False
        self.paused = False
        self.glued = False
        self.sent = None
        self.sep_pending = False
        self.tok = self.pend = ""
        self.raw = self.raw_emoticon = False

    # --- публичные клавиши: держим токен со ссылкой/знаками до пробела ---

    def _shadow_apply(self, action):
        if action:
            e, t = action
            self.shadow = self.shadow[:max(0, len(self.shadow) - e)] + t
        if len(self.shadow) > 4000:
            self.shadow = self.shadow[-2000:]

    def _resolve(self, ws, ws_step):
        """Пробел/Enter после задержанного токена: обработать его целиком, вернуть ОДНУ замену."""
        tok, pend = self.tok, self.pend
        self.tok = self.pend = ""
        before = self.shadow  # токен уже на экране, пробела/Enter в shadow ещё нет
        screen = before + ws
        head = tok.rstrip(RAW_TAIL)
        if EMOTICON.match(tok):
            head = tok
        if head and (is_raw_token(head) or EMOTICON.match(head)):
            # ядро держит в буфере только начало токена (буквы до первого знака)
            self.buffer = head
            self.raw = True
            self.raw_emoticon = bool(EMOTICON.match(head))
            work = before[:len(before) - len(tok)] + head
            replay = tok[len(head):]
        else:
            work = before[:len(before) - len(pend)]
            replay = pend
        last_undo = None
        for k, ch in enumerate(list(replay) + [ws]):
            work += ch
            a = ws_step() if k == len(replay) else self._feed_char(ch)
            if a:
                e, t = a
                work = work[:max(0, len(work) - e)] + t
            last_undo = self.undo
        self.shadow = work[-2000:]
        p = 0
        lim = min(len(screen), len(work))
        while p < lim and screen[p] == work[p]:
            p += 1
        if p == len(screen) == len(work):
            self.undo = None
            return None
        text = work[p:]
        self.undo = (len(text), screen[p:]) if last_undo else None
        return (len(screen) - p, text)

    def feed_char(self, ch: str):
        if ch.isspace():
            return self.feed_space() if ch == " " else None
        if self.pend or (ch in HOLD_INSIDE and self.tok) or (ch in HOLD_START and not self.tok):
            self.undo = None
            self.tok += ch
            self.pend += ch
            self.shadow += ch
            return None
        self.tok += ch
        self.shadow += ch
        a = self._feed_char(ch)
        self._shadow_apply(a)
        return a

    def feed_space(self):
        if self.pend:
            return self._resolve(" ", self._feed_space)
        self.tok = ""
        self.shadow += " "
        a = self._feed_space()
        self._shadow_apply(a)
        return a

    def feed_enter(self):
        if self.pend:
            return self._resolve("\n", self._feed_enter)
        self.tok = ""
        self.shadow += "\n"
        a = self._feed_enter()
        self._shadow_apply(a)
        return a

    def feed_backspace(self):
        """Backspace сразу после нашей замены отменяет её («каторый» остаётся как набран)."""
        if self.pend:
            self.pend = self.pend[:-1]
            self.tok = self.tok[:-1]
            self.shadow = self.shadow[:-1]
            return None
        self.tok = self.tok[:-1]
        self.shadow = self.shadow[:-1]
        a = self._feed_backspace()
        self._shadow_apply(a)
        return a


def apply_action(out: str, action) -> str:
    if action:
        erase, text = action
        out = out[: len(out) - erase] + text
    return out


def type_through(core: Corrector, text: str) -> str:
    """Прогнать текст через Corrector так, будто его напечатали."""
    out = ""
    for ch in text:
        out += ch
        if ch == "\n":
            a = core.feed_enter()
        elif ch == " ":
            a = core.feed_space()
        elif ch == "\b":
            a = core.feed_backspace()
            out = out[:-2]  # сам «\b» и стёртый им символ
        elif ch in "\t\r":
            core.break_context()
            a = None
        else:
            a = core.feed_char(ch)
        out = apply_action(out, a)
    return out


_DEFAULT = {}


def default_corrector(**kw) -> Corrector:
    """Corrector со словарями из папки программы (для fix_text и тестов)."""
    if "data" not in _DEFAULT:
        fixes, names = load_dictionary(find_dictionary())
        _DEFAULT["data"] = (fixes, names, load_punctuation())
    fixes, names, rules = _DEFAULT["data"]
    kw.setdefault("spell", get_spell_engine())
    return Corrector(fixes, names, rules, **kw)


_SPELL = {}


def get_spell_engine(wait=True):
    """Общий SpellEngine; грузится один раз (в фоне из GUI)."""
    if "engine" in _SPELL:
        return _SPELL["engine"]
    if not wait:
        return None
    try:
        from spell import SpellEngine
        path = find_data_file("ru_words.json.gz")
        _SPELL["engine"] = SpellEngine.from_file(path) if path else None
        if not path:
            logger.warning("ru_words.json.gz не найден — только dictionary.txt")
    except Exception as exc:
        logger.error("Словарь орфографии не загружен: %s", exc)
        _SPELL["engine"] = None
    return _SPELL["engine"]


def fix_text(text: str, core: Corrector = None) -> str:
    """Исправить готовый текст целиком (для Ctrl+Alt+C и тестов).

    Предложения, заглавные, запятые, пробелы после знаков, опечатки, точка в конце.
    """
    if not text or not text.strip():
        return text
    core = core or default_corrector()
    core.reset()
    body = text.replace("\r\n", "\n")
    stripped = body.rstrip(" \n")
    tail = body[len(stripped):]
    out = type_through(core, stripped + "\n")
    out = out[:-1]  # наш Enter
    last = out.rsplit(None, 1)[-1] if out.strip() else ""
    if out and out[-1].isalnum() and not core.after_emoticon and not is_raw_token(last):
        out += "."  # например, слово было прилеплено к ссылке; после самой ссылки — нет (v1.0.4.1)
    out += tail
    return out.replace("\n", "\r\n") if "\r\n" in text else out


SETTINGS_FILE = "settings.json"
DEFAULT_SETTINGS = {
    "enabled": True, "commas": True, "spelling": True, "pause_period": True, "questions": True,
    "autostart": False, "start_minimized": True, "hotkey_toggle": "<ctrl>+<alt>+<space>",
}


def settings_path() -> str:
    """settings.json рядом с exe, если он там есть (портативный режим), иначе %APPDATA%\\AutoCorrect."""
    local = os.path.join(app_dir(), SETTINGS_FILE)
    if os.path.exists(local):
        return local
    base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, "AutoCorrect", SETTINGS_FILE)


class SimpleSettings:
    """Запасные настройки, если ui.py недоступен. Тот же API, что у ui.Settings."""

    def __init__(self, path: str = None):
        self.path = path or settings_path()
        self.data = dict(DEFAULT_SETTINGS)
        self._listeners = []

    def load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if isinstance(raw, dict):
                for k, v in raw.items():
                    if k in DEFAULT_SETTINGS and type(v) is type(DEFAULT_SETTINGS[k]):
                        self.data[k] = v
        except FileNotFoundError:
            pass
        except Exception as exc:
            logger.warning("settings.json не прочитан: %s", exc)
        return self

    def save(self):
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
        except Exception as exc:  # папка только для чтения — просто не сохраняем
            logger.warning("settings.json не сохранён: %s", exc)

    def __getitem__(self, key):
        return self.data[key]

    def set(self, key, value):
        if key not in DEFAULT_SETTINGS:
            raise KeyError(key)
        if self.data.get(key) == value:
            return
        self.data[key] = value
        self.save()
        for cb in list(self._listeners):
            try:
                cb(key, value)
            except Exception as exc:
                logger.debug("settings listener: %s", exc)

    def toggle(self, key):
        self.set(key, not self.data[key])
        return self.data[key]

    def on_change(self, cb):
        self._listeners.append(cb)


def open_settings(path: str = None):
    path = path or settings_path()
    try:
        import ui
        return ui.Settings(path).load()
    except Exception as exc:
        logger.warning("ui.py недоступен (%s) — простые настройки", exc)
        return SimpleSettings(path).load()


def open_hook_log():
    """--debug-hook или AUTOCORRECT_DEBUG_HOOK=1: журнал в hook_log.txt рядом с exe (или в TEMP)."""
    if "--debug-hook" not in sys.argv and os.environ.get("AUTOCORRECT_DEBUG_HOOK") != "1":
        return None
    import tempfile
    for d in (app_dir(), tempfile.gettempdir()):
        try:
            f = open(os.path.join(d, "hook_log.txt"), "a", encoding="utf-8")
            logger.info("Журнал хука: %s", f.name)
            return f
        except Exception:
            continue
    return None


def make_guard():
    """WinGuard (кодер 3) только на Windows; без него работает старый путь pynput."""
    if sys.platform != "win32":
        return None
    try:
        from win_guard import WinGuard
        return WinGuard(find_data_file("blacklist.txt"))
    except Exception as exc:
        logger.error("win_guard: %s", exc)
        return None


# Windows: коды из WinUser.h
WM_KEYDOWN, WM_SYSKEYDOWN = 0x0100, 0x0104
LLKHF_INJECTED = 0x10
VK_BACK, VK_RETURN, VK_SPACE = 0x08, 0x0D, 0x20
MOD_VKS = {0x10, 0x11, 0x12, 0x14, 0x5B, 0x5C, 0x5D, 0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5}


class AutoCorrectApp:
    MODS = None
    VK_C = 0x43

    def __init__(self):
        from pynput import keyboard
        from pynput.keyboard import Controller, Key

        self.keyboard, self.Key = keyboard, Key
        self.controller = Controller()
        self.MODS = {
            Key.shift, Key.shift_r, Key.shift_l, Key.ctrl, Key.ctrl_r, Key.ctrl_l,
            Key.alt, Key.alt_r, Key.alt_l, Key.alt_gr, Key.cmd, Key.cmd_r, Key.cmd_l,
            Key.caps_lock,
        }
        self.CTRL = {Key.ctrl, Key.ctrl_l, Key.ctrl_r}
        self.ALT = {Key.alt, Key.alt_l, Key.alt_r, Key.alt_gr}
        self._init_state(open_settings(), make_guard())

        self.root = tk.Tk()
        self.root.title(f"Автокорректор {VERSION}")
        self.root.geometry("440x300")
        self.root.resizable(False, False)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self._set_window_icon()
        self._build_ui()
        # Большой словарь грузим в фоне — окно открывается сразу
        threading.Thread(target=self._load_spell, daemon=True).start()

    def _init_state(self, settings, guard):
        """Всё, кроме tk/pynput (тесты собирают app через __new__ + _init_state)."""
        self.held = set()
        self.lock = threading.Lock()
        self._injecting = False
        self._fix_pending = False
        self._undo_original = None
        self.listener = None
        self.mouse_listener = None
        self.is_active = False
        self.settings = settings
        self.guard = guard  # WinGuard (кодер 3) или None
        self._hook_log = open_hook_log()  # журнал хука (кодер 3), None если выключен
        self.root = None
        fixes, names = load_dictionary(find_dictionary())
        self.core = Corrector(fixes, names, load_punctuation(), settings=settings)
        settings.on_change(self._on_setting)

    def _set_window_icon(self):
        try:
            p = find_data_file(os.path.join("assets", "icon_64.png"))
            if p:
                self._icon_img = tk.PhotoImage(file=p)
                self.root.iconphoto(True, self._icon_img)
        except Exception as exc:
            logger.debug("иконка окна: %s", exc)

    def _build_ui(self):
        frame = ttk.Frame(self.root, padding=18)
        frame.pack(fill=tk.BOTH, expand=True)
        self.status_label = ttk.Label(frame, text="Статус: Выключено", font=("Segoe UI", 13, "bold"))
        self.status_label.pack(pady=(0, 10))
        self.toggle_btn = ttk.Button(frame, text="Включить", command=self._toggle, width=24)
        self.toggle_btn.pack(pady=4)
        self.vars = {}
        for key, label in (("commas", "Запятые"), ("spelling", "Орфография"),
                           ("pause_period", "Точка после паузы (2 с) и двойного пробела"),
                           ("questions", "Знак вопроса в конце вопроса")):
            var = tk.BooleanVar(value=bool(self.settings[key]))
            self.vars[key] = var
            ttk.Checkbutton(
                frame, text=label, variable=var,
                command=(lambda k=key, v=var: self.settings.set(k, bool(v.get()))),
            ).pack(anchor="w", padx=60)
        self.dict_label = ttk.Label(frame, text="Словарь: загрузка…", font=("Segoe UI", 9), foreground="gray")
        self.dict_label.pack(pady=(6, 0))
        ttk.Label(
            frame,
            text="Заглавные, точки, запятые и опечатки — сами.\n"
                 "Ctrl+Alt+C — исправить выделенный текст, Ctrl+Z — отменить замену.",
            justify=tk.CENTER, font=("Segoe UI", 9), foreground="gray",
        ).pack(pady=(6, 0))

    def _on_setting(self, key, value):
        """Галочка изменилась (в окне, в трее или в settings.json) — применить сразу."""
        with self.lock:
            self.core.apply_settings()
        var = getattr(self, "vars", {}).get(key)
        if var is not None and self.root is not None:
            try:
                self.root.after(0, lambda: var.set(bool(value)))
            except Exception:
                pass

    def _load_spell(self):
        t = time.perf_counter()
        eng = get_spell_engine()
        dt = time.perf_counter() - t
        with self.lock:
            self.core.spell = eng
        if eng is not None:
            text = f"Словарь: {len(eng):,} слов ({dt:.1f} с)".replace(",", " ")
        else:
            text = "Словарь: только dictionary.txt"
        logger.info(text)
        try:
            self.root.after(0, lambda: self.dict_label.config(text=text))
        except Exception:
            pass

    def _toggle(self):
        if not self.is_active:
            self.is_active = True
            self.toggle_btn.config(text="Выключить")
            self.status_label.config(text="Статус: Включено", foreground="green")
            self._start()
        else:
            self.is_active = False
            self.toggle_btn.config(text="Включить")
            self.status_label.config(text="Статус: Выключено", foreground="black")
            self._stop()
        self.settings.set("enabled", self.is_active)

    def _start(self):
        self.core.reset()
        self.held.clear()
        kwargs = {}
        if sys.platform == "win32":
            # Enter перехватываем до того, как его получит программа:
            # иначе мессенджер отправит сообщение раньше, чем мы поставим точку.
            kwargs["win32_event_filter"] = self._win_filter
        self.listener = self.keyboard.Listener(
            on_press=self._on_press, on_release=self._on_release, **kwargs
        )
        self.listener.daemon = True
        self.listener.start()
        try:
            from pynput import mouse
            self.mouse_listener = mouse.Listener(on_click=self._on_click)
            self.mouse_listener.daemon = True
            self.mouse_listener.start()
        except Exception as exc:
            logger.debug("mouse listener: %s", exc)

    def _stop(self):
        for l in (self.listener, self.mouse_listener):
            if l is not None:
                try:
                    l.stop()
                except Exception:
                    pass
        self.listener = self.mouse_listener = None
        self.core.reset()

    def _on_click(self, x, y, button, pressed):
        if pressed and not self._injecting:
            with self.lock:
                self.core.break_context()

    def _on_release(self, key):
        self.held.discard(key)
        if self._fix_pending and not (self.held & (self.CTRL | self.ALT)):
            # Ждём, пока отпустят Ctrl+Alt, иначе наш Ctrl+C станет Ctrl+Alt+C
            self._fix_pending = False
            self.root.after(50, self._fix_selection_start)

    def _is_hotkey_c(self, key) -> bool:
        if not (self.held & self.CTRL and self.held & self.ALT):
            return False
        if getattr(key, "vk", None) == self.VK_C:  # работает и в русской раскладке
            return True
        return getattr(key, "char", None) in ("c", "C", "с", "С", "\x03")

    def _on_press(self, key):
        if not self.is_active or self._injecting:
            return
        Key = self.Key
        try:
            if key in self.MODS:
                if key not in (Key.shift, Key.shift_r, Key.shift_l, Key.caps_lock):
                    self.held.add(key)
                return
            if self.held:  # Ctrl/Alt/Win + что-то — это хоткей, не текст
                if self._is_hotkey_c(key):
                    self._fix_pending = True
                with self.lock:
                    self.core.break_context()
                return
            if self.guard is not None:
                return  # на Windows с WinGuard текст разбирает _win_filter
            with self.lock:
                char = getattr(key, "char", None)
                if char is not None and char.isprintable():
                    action = self.core.feed_char(char)
                elif key == Key.space:
                    action = self.core.feed_space()
                elif key == Key.enter:
                    if sys.platform == "win32":
                        return  # уже обработан в _win_filter
                    action = self.core.feed_enter()
                elif key == Key.backspace:
                    action = self.core.feed_backspace()
                else:
                    self.core.break_context()
                    return
            if action:
                undo = self.core.undo
                self._undo_original = undo[1] if (undo and key != Key.backspace) else False
                self._apply(*action)
        except Exception as exc:
            logger.debug("Ошибка обработки клавиши: %s", exc)

    # --- Ctrl+Alt+C: исправить выделенный текст ---

    def _send_combo(self, letter: str):
        Key = self.Key
        self._injecting = True
        try:
            with self.controller.pressed(Key.ctrl):
                self.controller.press(self.keyboard.KeyCode.from_vk(ord(letter.upper())))
                self.controller.release(self.keyboard.KeyCode.from_vk(ord(letter.upper())))
            time.sleep(0.03)
        finally:
            self._injecting = False

    def _clipboard_get(self):
        try:
            return self.root.clipboard_get()
        except Exception:
            return None

    def _clipboard_set(self, text):
        self.root.clipboard_clear()
        if text is not None:
            self.root.clipboard_append(text)
        self.root.update()

    def _fix_selection_start(self):
        """Шаг 1 (главный поток): запомнить буфер обмена и скопировать выделение."""
        self._saved_clip = self._clipboard_get()
        self._sentinel = f"__autocorrect_{time.time()}__"
        self._clipboard_set(self._sentinel)
        threading.Thread(target=lambda: (self._send_combo("c"), self.root.after(150, self._fix_selection_copy)),
                         daemon=True).start()

    def _fix_selection_copy(self):
        """Шаг 2: прочитать выделенное, исправить, вставить через Ctrl+V."""
        text = self._clipboard_get()
        if not text or text == self._sentinel:
            logger.info("Ctrl+Alt+C: ничего не выделено")
            self._restore_clipboard()
            return
        try:
            with self.lock:
                fixed = fix_text(text, Corrector(
                    self.core.fixes, self.core.names, self.core.rules, self.core.spell,
                    settings=self.core.settings, comma_rules=self.core.commas))
        except Exception as exc:
            logger.error("fix_text: %s", exc)
            fixed = text
        if fixed == text:
            self._restore_clipboard()
            return
        self._clipboard_set(fixed)
        threading.Thread(target=lambda: (self._send_combo("v"), self.root.after(400, self._restore_clipboard)),
                         daemon=True).start()
        with self.lock:
            self.core.break_context()

    def _restore_clipboard(self):
        try:
            self._clipboard_set(self._saved_clip)
        except Exception as exc:
            logger.debug("clipboard restore: %s", exc)

    def _win_filter(self, msg, data):
        """Обёртка: при --debug-hook / AUTOCORRECT_DEBUG_HOOK=1 пишет журнал хука."""
        if self._hook_log is None:
            return self._win_filter_core(msg, data)
        before = len(self.core.buffer)
        try:
            res = self._win_filter_core(msg, data)
        except BaseException:
            self._log_hook(msg, data, "suppress", before)
            raise
        self._log_hook(msg, data, "pass" if res else "stop", before)
        return res

    def _log_hook(self, msg, data, decision, before):
        try:
            g = self.guard
            kind = ("ours" if g and g.is_ours(data) else "replay" if g and g.is_replay(data)
                    else "inj" if data.flags & LLKHF_INJECTED else "hw")
            self._hook_log.write(
                "%.3f msg=%04X vk=%02X scan=%02X flags=%02X extra=%X kind=%s busy=%d "
                "decision=%s buf=%d->%d\n" % (
                    time.monotonic(), msg, data.vkCode, data.scanCode, data.flags,
                    getattr(data, "dwExtraInfo", 0) or 0, kind,
                    int(bool(g and g.gate.busy)), decision, before, len(self.core.buffer)))
            self._hook_log.flush()
        except Exception:
            pass

    def _win_filter_core(self, msg, data):
        """Низкоуровневый фильтр Windows (поток хука). True — отдать событие дальше.

        С WinGuard весь набор разбирается здесь: тут есть vk/scan и метка dwExtraInfo.
        Порядок важен: наши события и очередь (кодер 3) — раньше Ctrl+Z (ui.py
        оборачивает этот метод и проверяет is_ours/is_replay/busy до Ctrl+Z).
        """
        g = self.guard
        if g is None:
            return self._win_filter_enter_only(msg, data)
        if not self.is_active:
            return True
        if g.is_ours(data):
            return False  # наша замена: в окно идёт, в Corrector и _on_press — нет
        if g.hold_if_busy(msg, data):  # идёт замена — клавиша в очередь
            self.listener.suppress_event()
            return False
        if msg not in (WM_KEYDOWN, WM_SYSKEYDOWN):
            return True
        if self._injecting:
            return True  # наш Ctrl+C/Ctrl+V через pynput — не текст пользователя
        # Чужой инжект (экранная клавиатура, удалённый доступ, Punto, e2e-робот)
        # принимаем как текст пользователя: свои события отсечены выше по is_ours.
        vk = data.vkCode
        if vk in MOD_VKS:
            return True
        reason, hkl = g.context()
        if reason:  # пароль / чёрный список / полноэкранная игра
            with self.lock:
                self.core.break_context()
            return True
        if g.layout.changed(hkl):
            with self.lock:
                self.core.break_context()
        if self.held:  # Ctrl/Alt/Win + клавиша — хоткей, см. _on_press
            with self.lock:
                self.core.break_context()
            return True
        with self.lock:
            if vk == VK_RETURN:
                action = self.core.feed_enter()
                if action:
                    # Enter ещё не напечатан: стираем на один символ меньше, Enter — в конце text
                    self._begin_replace(action[0] - 1, action[1], False)
                    self.listener.suppress_event()
                    return False
                return True
            if vk == VK_BACK:
                action = self.core.feed_backspace()
                if action:
                    # отмена нашей замены: сам Backspace глушим, стираем всё сами
                    self._begin_replace(action[0] + 1, action[1], False)
                    self.listener.suppress_event()
                    return False
                return True
            if vk == VK_SPACE:
                action = self.core.feed_space()
            else:
                ch = g.translate(vk, data.scanCode, hkl)
                if ch and ch.isprintable():
                    action = self.core.feed_char(ch)
                else:
                    self.core.break_context()  # стрелки, Tab, Delete, F-клавиши…
                    return True
            if action:
                undo = self.core.undo
                self._begin_replace(action[0], action[1], undo[1] if undo else False)
        return True

    def _begin_replace(self, erase, text, original):
        """Из хука: закрыть ворота (клавиши — в очередь) и заменить в фоне.

        original — что набрал человек (для Ctrl+Z в ui.py), False — не отменять.
        """
        self._undo_original = original
        self.guard.gate.begin()  # ВАЖНО: в хуке, до запуска потока
        threading.Thread(target=self._apply, args=(erase, text), daemon=True).start()

    def _win_filter_enter_only(self, msg, data):
        """Без WinGuard (как в v1.0.2): ловим только Enter, остальное — в _on_press."""
        if (
            not self.is_active or self._injecting  # чужой инжект (экранная клавиатура) — принимаем
            or data.vkCode != VK_RETURN
            or msg not in (WM_KEYDOWN, WM_SYSKEYDOWN)
        ):
            return True
        if self.held:  # Ctrl+Enter и т.п. — не трогаем
            with self.lock:
                self.core.break_context()
            return True
        with self.lock:
            action = self.core.feed_enter()
        if not action:
            return True
        erase, text = action
        self._injecting = True
        self._undo_original = False
        threading.Thread(target=self._apply, args=(erase - 1, text), daemon=True).start()
        self.listener.suppress_event()  # дальше этой строки код не идёт

    def _apply(self, erase: int, text: str):
        """Единая точка замены (ui.py оборачивает её для Ctrl+Z)."""
        if self.guard is not None:
            time.sleep(0.005)  # дать исходной клавише дойти до окна
            self.guard.replace(erase, text)  # один SendInput + переигрывание очереди
            return
        Key = self.Key
        self._injecting = True
        try:
            time.sleep(0.01)  # дать системе доставить исходную клавишу
            for _ in range(erase):
                self.controller.press(Key.backspace)
                self.controller.release(Key.backspace)
                time.sleep(0.002)
            for ch in text:
                if ch == "\n":
                    self.controller.press(Key.enter)
                    self.controller.release(Key.enter)
                else:
                    self.controller.type(ch)
            time.sleep(0.03)  # наши же события не должны попасть в буфер
        except Exception as exc:
            logger.debug("Ошибка замены: %s", exc)
        finally:
            self._injecting = False

    def _on_close(self):
        self.is_active = False
        self._stop()
        self.root.destroy()

    def run(self):
        self.root.mainloop()


def main():
    app = AutoCorrectApp()
    try:
        import ui
        ui.install(app, settings=app.settings)  # трей, хоткей вкл/выкл, Ctrl+Z, автозапуск
    except Exception as exc:
        logger.error("UI: %s", exc)
        if app.settings["enabled"]:
            app._toggle()
    app.run()


if __name__ == "__main__":
    main()
